import os
from urllib.parse import urlparse

from cmlapi.api.cml_service_api import CMLServiceApi
from cmlapi.api_client import ApiClient
from cmlapi.configuration import Configuration

session_ca_cert_path = "/etc/ssl/certs/ca-certificates.crt"


def default_client(url=None, cml_api_key=None):
    """Creates a default client for api server.

    This method takes url and cml_api_key as parameters and returns a
    client object. if neither url nor cml_api_key are provided they will be
    read from environment variables, CDSW_API_URL for url and CDSW_APIV2_KEY
    for cml_api_key.

    :param str url: API server URL that serves client requests.
    :param str cml_api_key: The apikey is used to authenticate client requests to server.
    :return:  CMLServiceApi client.
    """
    config = Configuration()
    if os.path.exists(session_ca_cert_path):
        config.ssl_ca_cert = session_ca_cert_path
    if url == None:
        try:
            urlobj = urlparse(os.environ["CDSW_API_URL"])
            url = urlobj.scheme + "://" + urlobj.netloc
        except KeyError:
            raise ValueError("Environment variable CDSW_API_URL not set.")
    if not url.startswith("https") and not url.startswith("http"):
        raise ValueError(
            "Protocol missing in url {0}. please specify http or https protocol.".format(
                url
            )
        )
    config.host = url.rstrip("/")
    if cml_api_key == None:
        cml_api_key = os.getenv("CDSW_APIV2_KEY")
        if cml_api_key == None:
            raise ValueError("Environment variable CDSW_APIV2_KEY not set.")
    client = ApiClient(config)
    client.set_default_header("authorization", "Bearer " + cml_api_key)
    api = CMLServiceApi(client)
    return api
