# CreateProjectRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of the project to create. | [optional] 
**description** | **str** | The description of the project. | [optional] 
**visibility** | **str** | The visibility of the project (one of \&quot;public\&quot;, \&quot;organization\&quot;, \&quot;private\&quot;). Default is private. | [optional] 
**parent_project** | **str** | Optional parent project to fork. | [optional] 
**git_url** | **str** | Optional git URL to checkout for this project. | [optional] 
**template** | **str** | Optional template to use (Python, R, PySpark, Scala, Churn Predictor) Note: local will create the project but nothing else, files must be uploaded separately. | [optional] 
**organization_permission** | **str** | If this is an organization-wide project, the visibility to others in the organization. | [optional] 
**default_project_engine_type** | **str** | Whether this project uses legacy engines or runtimes. Valid values are \&quot;ml_runtime\&quot;, \&quot;legacy_engine\&quot;, or leave blank to default to the site-wide default. | [optional] 
**environment** | **dict(str, str)** |  | [optional] 
**shared_memory_limit** | **int** | Additional shared memory limit that engines in this project should have, in MB (default 64). | [optional] 
**team_name** | **str** |  | [optional] 
**git_ref** | **str** | Optional git ref to checkout for this project. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

