# CreateJobRunRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | ID of the project containing the job. | [optional] 
**job_id** | **str** | The job ID to create a new job run for. | [optional] 
**environment** | **dict(str, str)** | The environment variables to include in this run. | [optional] 
**arguments** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

