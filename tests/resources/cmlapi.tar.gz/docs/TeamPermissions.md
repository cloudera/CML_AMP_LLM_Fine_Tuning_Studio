# TeamPermissions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**business_user** | **bool** | business_user can access application. | [optional] 
**read** | **bool** | Read-only, aka Viewer. Can view code, data, and results. | [optional] 
**operator** | **bool** | operator can start or stop pre-existing jobs. | [optional] 
**write** | **bool** | Read-write, aka Contributor. Can view and modify all project resources. | [optional] 
**admin** | **bool** | Administrator. Can view and modify all project resources, add new collaborators, and delete the project. | [optional] 
**owner** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

