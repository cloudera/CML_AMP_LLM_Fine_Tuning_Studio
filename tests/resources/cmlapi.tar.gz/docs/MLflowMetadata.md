# MLflowMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**experiment_id** | **str** | Experiment ID the run belongs to. | [optional] 
**run_id** | **str** | Run ID. | [optional] 
**metrics** | [**list[Metric]**](Metric.md) | Metrics for the run. | [optional] 
**params** | [**list[Tag]**](Tag.md) | ExperimentRun parameters. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Additional metadata key-value pairs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

