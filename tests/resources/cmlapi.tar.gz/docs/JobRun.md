# JobRun

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** | The project that this job run belongs to. This is an opaque identifier. | [optional] 
**job_id** | **str** | The job that this job run belongs to. This is an opaque identifier. | [optional] 
**status** | [**EngineStatus**](EngineStatus.md) |  | [optional] 
**id** | **str** | The alphanumeric identifier for the job run. | [optional] 
**created_at** | **datetime** | The timestamp of when the job run was created. | [optional] 
**scheduling_at** | **datetime** | The timestamp the job run was scheduled at. | [optional] 
**starting_at** | **datetime** | The tiemstamp the job run started being processed. | [optional] 
**running_at** | **datetime** | The timestamp the job run started running. | [optional] 
**finished_at** | **datetime** | The timestamp the job run finished. | [optional] 
**kernel** | **str** | The kernel of the job run. This value is inherited from the job when the job run is started. If the job is later edited, this will still represent the kernel this job run ran with. | [optional] 
**cpu** | **float** | The number of vCPU allocated for the job run (in cores). This value is inherited from the job when the job run is started. If the job is later edited, this will still represent the number of CPU this job run ran with. | [optional] 
**memory** | **float** | The amount of memory allocated for the job run (in GB). This value is inherited from the job when the job run is started. If the job is later edited, this will still represent the amount of memory this job run ran with. | [optional] 
**nvidia_gpu** | **int** | The number of Nvidia GPUs allocated for the job run. This value is inherited from the job when the job run is started. If the job is later edited, this will still represent the number of GPUs this job run ran with. | [optional] 
**arguments** | **str** | The custom arguments to the job run. | [optional] 
**environment** | **str** |  | [optional] 
**creator** | [**ShortUser**](ShortUser.md) |  | [optional] 
**runtime_identifier** | **str** | The runtime image identifier if this used a runtime engine. Blank if this used a legacy engine. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

