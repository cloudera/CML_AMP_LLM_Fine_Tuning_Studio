# LogExperimentRunBatchRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**experiment_id** | **str** |  | [optional] 
**run_id** | **str** |  | [optional] 
**metrics** | [**list[Metric]**](Metric.md) | Metrics to log. | [optional] 
**params** | [**list[Tag]**](Tag.md) | Params to log. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Tags to log. | [optional] 
**model_json** | **str** | MLmodel file in json format. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

