# ShortUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** | The username. | [optional] 
**name** | **str** | The user&#x27;s full name. | [optional] 
**email** | **str** | The user&#x27;s email address. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

