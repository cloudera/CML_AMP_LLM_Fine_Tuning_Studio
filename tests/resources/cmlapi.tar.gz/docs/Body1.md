# Body1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadata** | **str** | Custom Runtime Addon metadata in JSON format. | 
**tarball** | **str** | Tarball with the contents of the new Custom Runtime Addon | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

