# Model

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the model. A model CRN looks like &lt;workspace CRN&gt;/&lt;UUID&gt;. The model ID is the UUID portion of the CRN. | [optional] 
**name** | **str** | The name of the model. | [optional] 
**description** | **str** | The description of the model. | [optional] 
**creator** | [**ShortUser**](ShortUser.md) |  | [optional] 
**access_key** | **str** | The model&#x27;s access key. | [optional] 
**deletion_status** | **str** | The models deletion status. | [optional] 
**created_at** | **datetime** | When the model was created. | [optional] 
**updated_at** | **datetime** | When the model was last updated. | [optional] 
**crn** | **str** | CRN of the model. | [optional] 
**auth_enabled** | **bool** | Enable model authentication. | [optional] 
**project** | [**ShortProject**](ShortProject.md) |  | [optional] 
**registered_model_id** | **str** | Registered Model ID reference to model Regisry. | [optional] 
**visibility** | **str** | Visibility of the model. | [optional] 
**default_resources** | [**DefaultResources**](DefaultResources.md) |  | [optional] 
**default_replication_policy** | [**DefaultReplicationPolicy**](DefaultReplicationPolicy.md) |  | [optional] 
**run_as** | **int** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

