# CreateTeamRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** | ID of the project containing the model. | [optional] 
**type** | **str** |  | [optional] 
**cn** | **str** | cn of the team. | [optional] 
**bio** | **str** | bio of the team. | [optional] 
**permission** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

