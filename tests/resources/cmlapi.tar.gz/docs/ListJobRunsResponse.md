# ListJobRunsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_runs** | [**list[JobRun]**](JobRun.md) | A list of job runs. | [optional] 
**next_page_token** | **str** | A token for the next page of job runs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

