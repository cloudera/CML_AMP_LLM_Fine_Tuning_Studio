# TimeSeriesResultValues

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time_stamp** | **str** |  | [optional] 
**count** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

