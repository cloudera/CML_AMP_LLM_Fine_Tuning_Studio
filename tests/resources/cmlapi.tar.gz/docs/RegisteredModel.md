# RegisteredModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_id** | **str** | Model ID. | [optional] 
**name** | **str** | Model name. | [optional] 
**description** | **str** | Model description. | [optional] 
**owner** | [**ShortUser**](ShortUser.md) |  | [optional] 
**permission** | **str** | Permission of the user requesting the model. | [optional] 
**visibility** | [**Visibility**](Visibility.md) |  | [optional] 
**created_at** | **datetime** | Model creation time. | [optional] 
**updated_at** | **datetime** | Model last updated time. | [optional] 
**count** | **int** | Model version count. | [optional] 
**model_versions** | [**list[RegisteredModelVersion]**](RegisteredModelVersion.md) | Registered model versions list. | [optional] 
**next_page_token** | **str** | next_page_token is a token to get the next page of results. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

