# ListV2KeysResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**list[V2KeyDetails]**](V2KeyDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

