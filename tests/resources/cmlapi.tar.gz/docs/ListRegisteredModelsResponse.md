# ListRegisteredModelsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**models** | [**list[RegisteredModelDetails]**](RegisteredModelDetails.md) | List of registered models. | [optional] 
**next_page_token** | **str** | Next page token. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

