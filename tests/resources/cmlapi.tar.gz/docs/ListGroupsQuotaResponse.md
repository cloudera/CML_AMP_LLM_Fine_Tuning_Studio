# ListGroupsQuotaResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_quota** | [**list[GroupQuota]**](GroupQuota.md) |  | [optional] 
**next_page_token** | **str** | Next page token. | [optional] 
**total_count** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

