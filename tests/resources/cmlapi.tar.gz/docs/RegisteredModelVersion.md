# RegisteredModelVersion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_id** | **str** | Model ID. | [optional] 
**model_version_id** | **str** | Model version ID. | [optional] 
**version_name** | **str** | Model version name. | [optional] 
**number** | **int** | Model version number. | [optional] 
**notes** | **str** | Model version description. | [optional] 
**user** | [**ShortUser**](ShortUser.md) |  | [optional] 
**created_at** | **datetime** | Model version creation time. | [optional] 
**updated_at** | **datetime** | Model version last updated time. | [optional] 
**status** | **str** | Model version status. | [optional] 
**model_version_metadata** | [**ModelVersionMetadata**](ModelVersionMetadata.md) |  | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Model version tags. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

