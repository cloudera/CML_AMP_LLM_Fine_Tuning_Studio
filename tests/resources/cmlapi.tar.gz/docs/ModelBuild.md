# ModelBuild

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the model build. | [optional] 
**model_id** | **str** | ID of the model containing the build. | [optional] 
**creator** | [**ShortUser**](ShortUser.md) |  | [optional] 
**comment** | **str** | The comment associated with the build. | [optional] 
**file_path** | **str** | Path from the project root to the file to build. | [optional] 
**function_name** | **str** | Name of the function to run. | [optional] 
**engine_image** | **str** | The engine image to build the model with. | [optional] 
**kernel** | **str** | The kernel to run the build with. | [optional] 
**created_at** | **datetime** | When the model build was created. | [optional] 
**updated_at** | **datetime** | When the model build was most recently updated. | [optional] 
**status** | **str** | Status of the build. | [optional] 
**deletion_status** | **str** | State of the deletion of the build. | [optional] 
**crn** | **str** | CRN of the build. | [optional] 
**built_at** | **datetime** | When the model build was most recently updated. | [optional] 
**runtime_identifier** | **str** | Runtime identifier if this model uses runtimes. | [optional] 
**runtime_addon_identifiers** | **list[str]** | Runtime addons if this model uses runtimes. | [optional] 
**registered_model_version_id** | **str** | ID of the registered model version. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

