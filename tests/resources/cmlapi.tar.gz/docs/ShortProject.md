# ShortProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**public_identifier** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**default_project_engine** | **str** |  | [optional] 
**slug** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

