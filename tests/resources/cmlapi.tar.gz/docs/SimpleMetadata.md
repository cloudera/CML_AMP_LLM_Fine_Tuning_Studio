# SimpleMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**git_url** | **str** | git url for model code. | [optional] 
**commit_id** | **str** | commit sha for model code. | [optional] 
**metrics** | [**list[Metric]**](Metric.md) | metrics for the model. | [optional] 
**params** | [**list[Tag]**](Tag.md) | ExperimentRun parameters. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Additional metadata key-value pairs. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

