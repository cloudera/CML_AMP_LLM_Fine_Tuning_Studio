# ListWorkloadTypesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workload_type** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

