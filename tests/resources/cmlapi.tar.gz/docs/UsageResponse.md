# UsageResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**creator** | **str** |  | [optional] 
**group** | **str** |  | [optional] 
**project_name** | **str** |  | [optional] 
**cpu** | **float** |  | [optional] 
**memory** | **float** |  | [optional] 
**nvidia_gpu** | **float** |  | [optional] 
**workload_type** | **str** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**duration** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**creator_info** | [**UserOrGroupInfo**](UserOrGroupInfo.md) |  | [optional] 
**group_info** | [**UserOrGroupInfo**](UserOrGroupInfo.md) |  | [optional] 
**project_info** | [**ProjectInfo**](ProjectInfo.md) |  | [optional] 
**id** | **str** |  | [optional] 
**workload_url** | **str** |  | [optional] 
**message** | **str** |  | [optional] 
**oom_killed** | **bool** |  | [optional] 
**k8s_info** | [**K8SInfo**](K8SInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

