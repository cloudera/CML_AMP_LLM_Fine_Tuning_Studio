# Project

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | An opaque public identifier for the project. Output only. | [optional] 
**name** | **str** | The short name; does not include user/team. | [optional] 
**owner** | [**ShortUser**](ShortUser.md) |  | [optional] 
**creator** | [**ShortUser**](ShortUser.md) |  | [optional] 
**description** | **str** | Describes the project. | [optional] 
**visibility** | **str** |  | [optional] 
**default_engine_type** | **str** | Whether this project uses engines or runtimes: \&quot;ml_runtime\&quot; or \&quot;legacy_engine\&quot;. | [optional] 
**created_at** | **datetime** | Birth date in YYYY-MM-DDThh:mm:ss.uuZ format (ISO 8601 format). Output only. | [optional] 
**updated_at** | **datetime** | Last update in YYYY-MM-DDThh:mm:ss.uuZ format (ISO 8601 format). Output only. | [optional] 
**creation_status** | **str** | Creation status of the project (e.g. creating, success, failure) Output only. | [optional] 
**permissions** | [**ProjectPermissions**](ProjectPermissions.md) |  | [optional] 
**shared_memory_limit** | **int** | Additional shared memory limit that each engine in this project has, in MB. | [optional] 
**environment** | **str** | The environment variables configured for this project. | [optional] 
**ephemeral_storage_request** | **int** | The ephemeral storage requested for the project, in GB. | [optional] 
**ephemeral_storage_limit** | **int** | The ephemeral storage limit for the project, in GB. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

