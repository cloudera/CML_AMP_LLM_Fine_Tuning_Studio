# Metric

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** | Key identifying this metric. | [optional] 
**value** | **float** | Value associated with this metric. | [optional] 
**timestamp** | **datetime** | The timestamp at which this metric was recorded. | [optional] 
**step** | **str** | Step at which to log the metric. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

