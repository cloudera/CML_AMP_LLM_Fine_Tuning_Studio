# TimeSeriesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**series_type** | **str** | Type of the time series. | [optional] 
**result** | [**TimeSeriesResult**](TimeSeriesResult.md) |  | [optional] 
**next_page_token** | **str** | Next page token. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

