# BatchListProjectsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projects** | [**list[Project]**](Project.md) | The list of projects. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

