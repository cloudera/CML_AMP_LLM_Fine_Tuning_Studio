# NewsFeed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**category** | **str** |  | [optional] 
**tags** | **list[str]** |  | [optional] 
**link** | **str** |  | [optional] 
**imgpath** | **str** |  | [optional] 
**is_viewed** | **bool** |  | [optional] 
**_date** | **datetime** | created at YYYY-MM-DDThh:mm:ss.uuZ format (ISO 8601 format). | [optional] 
**icon** | **str** |  | [optional] 
**is_new** | **bool** |  | [optional] 
**description_html** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

