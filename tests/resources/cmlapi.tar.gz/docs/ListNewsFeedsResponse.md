# ListNewsFeedsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feeds** | [**list[NewsFeed]**](NewsFeed.md) |  | [optional] 
**next_page_token** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

