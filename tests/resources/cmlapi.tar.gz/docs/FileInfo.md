# FileInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** | The relative path to the file or directory. The path is relative to the base resource that this file represents. For example, if it&#x27;s a project file/directory, it will be relative to /home/cdsw. Alternatively, if it&#x27;s an experiment run artifact, it will be relative to the experiment run&#x27;s root artifact directory. | [optional] 
**is_dir** | **bool** | Whether the path is a directory. Output only. | [optional] 
**file_size** | **str** | Size in bytes. Unset for directories. Output only. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

