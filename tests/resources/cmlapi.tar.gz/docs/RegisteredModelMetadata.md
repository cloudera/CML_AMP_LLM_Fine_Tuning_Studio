# RegisteredModelMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_path** | **str** | model_path artifact folder name. | [optional] 
**model_name** | **str** | model_name. | [optional] 
**model_id** | **str** | model_id of the registered model id. | [optional] 
**model_version_id** | **str** | model_version_id of the. | [optional] 
**version_number** | **int** | count of the model version. | [optional] 
**run_id** | **str** | run_id of the experiment run. | [optional] 
**created_at** | **datetime** | created_at timestamp of model registered. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

