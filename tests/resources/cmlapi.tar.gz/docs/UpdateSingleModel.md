# UpdateSingleModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the model. A model CRN looks like &lt;workspace CRN&gt;/&lt;UUID&gt;. The ID is the UUID portion of the CRN. | [optional] 
**name** | **str** | The name of the model. | [optional] 
**description** | **str** | The description of the model. | [optional] 
**visibility** | **str** | Visibility of the model. | [optional] 
**default_resources** | [**DefaultResources**](DefaultResources.md) |  | [optional] 
**default_replication_policy** | [**DefaultReplicationPolicy**](DefaultReplicationPolicy.md) |  | [optional] 
**run_as** | **int** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

