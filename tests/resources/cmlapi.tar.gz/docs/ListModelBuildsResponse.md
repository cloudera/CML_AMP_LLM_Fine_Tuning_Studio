# ListModelBuildsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_builds** | [**list[ModelBuild]**](ModelBuild.md) | The page of model builds. | [optional] 
**next_page_token** | **str** | The next page token. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

