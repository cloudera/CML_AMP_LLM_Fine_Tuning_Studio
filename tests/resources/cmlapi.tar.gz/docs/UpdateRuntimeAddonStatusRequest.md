# UpdateRuntimeAddonStatusRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**UpdateRuntimeAddonStatusRequestRuntimeAddonStatus**](UpdateRuntimeAddonStatusRequestRuntimeAddonStatus.md) |  | [optional] 
**ids** | **list[int]** | List of runtime addons to update (not recommended). | [optional] 
**identifiers** | **list[str]** | List of runtime addons to update. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

