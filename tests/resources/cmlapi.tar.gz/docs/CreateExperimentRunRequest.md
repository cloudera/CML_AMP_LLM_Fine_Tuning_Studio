# CreateExperimentRunRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**experiment_id** | **str** | ID of the associated experiment. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Additional metadata for ExperimentRun. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

