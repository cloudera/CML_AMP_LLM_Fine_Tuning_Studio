# ShortCreateModelDeployment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu** | **float** | Number of vCPU to allocate to the deployment. | [optional] 
**memory** | **float** | Amount of memory in GB to allocate to the deployment. | [optional] 
**nvidia_gpus** | **int** | Number of nvidia GPUs to allocate to the deployment. | [optional] 
**environment** | **dict(str, str)** | Environment variables to run the deployment with. | [optional] 
**replicas** | **int** | Number of Replications. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

