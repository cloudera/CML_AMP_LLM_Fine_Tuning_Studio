# ListProjectsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projects** | [**list[Project]**](Project.md) | Projects is the response object with details on a list of projects. | [optional] 
**next_page_token** | **str** | Next page token is a value that can be added to a new ListProjects call to fetch the next page of projects, if any remain. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

