# Runtime

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image_identifier** | **str** | The identifier for this runtime. | [optional] 
**editor** | **str** | The editor configured for this runtime. | [optional] 
**kernel** | **str** | The kernel associated with this runtime. | [optional] 
**edition** | **str** | The edition of this runtime. | [optional] 
**description** | **str** | A short description of the runtime. | [optional] 
**full_version** | **str** | The full version of the runtime. | [optional] 
**status** | **str** | Status of the runtime. | [optional] 
**register_user_id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

