# ListRuntimeAddonsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**runtime_addons** | [**list[RuntimeAddon]**](RuntimeAddon.md) |  | [optional] 
**next_page_token** | **str** | A token to fetch the next page of runtime addons. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

