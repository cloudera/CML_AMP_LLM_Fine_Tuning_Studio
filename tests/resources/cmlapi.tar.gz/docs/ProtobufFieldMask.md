# ProtobufFieldMask

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paths** | **list[str]** | The set of field mask paths. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

