# RegisterCustomRuntimeResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**validation_success** | **bool** |  | [optional] 
**insert_success** | **bool** |  | [optional] 
**reason** | **str** |  | [optional] 
**reason_data** | **str** |  | [optional] 
**details** | [**CustomRuntimeImageDetails**](CustomRuntimeImageDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

