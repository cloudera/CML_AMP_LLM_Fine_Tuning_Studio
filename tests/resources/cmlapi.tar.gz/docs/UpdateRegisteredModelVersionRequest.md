# UpdateRegisteredModelVersionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_id** | **str** | Model ID. | [optional] 
**model_version_id** | **str** | Model version ID. | [optional] 
**notes** | **str** | Model version description. | [optional] 
**tags** | [**list[Tag]**](Tag.md) | Model version tags. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

