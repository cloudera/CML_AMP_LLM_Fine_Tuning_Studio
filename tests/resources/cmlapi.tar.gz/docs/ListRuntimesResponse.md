# ListRuntimesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**runtimes** | [**list[Runtime]**](Runtime.md) | The page of runtimes. | [optional] 
**next_page_token** | **str** | A token to fetch the next page of runtimes. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

