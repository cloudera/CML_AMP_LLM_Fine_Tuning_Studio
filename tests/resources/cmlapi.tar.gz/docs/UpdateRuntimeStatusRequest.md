# UpdateRuntimeStatusRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**RuntimeStatus**](RuntimeStatus.md) |  | [optional] 
**runtime_id** | **list[int]** | List of runtimes to update (not recommended). | [optional] 
**image_identifier** | **list[str]** | List of runtimes to update. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

