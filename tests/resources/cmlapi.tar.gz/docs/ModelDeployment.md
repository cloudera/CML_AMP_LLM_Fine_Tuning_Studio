# ModelDeployment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**model_id** | **str** | ID of the model containing the deployment. | [optional] 
**build_id** | **str** | ID of the build containing the deployment. | [optional] 
**id** | **str** | ID of the model deployment. This is derived from the model deployment CRN. The model deployment CRN is of the form &lt;workspace CRN&gt;/&lt;UUID&gt;, and this ID is the UUID portion of the model deployment CRN. | [optional] 
**cpu** | **float** | Number of vCPUs allocated to this deployment. | [optional] 
**memory** | **float** | Amount of memory to allocate to this deployment. | [optional] 
**nvidia_gpu** | **int** | Number of Nvidia GPUs to allocate to  this project. | [optional] 
**environment** | **str** | Environment variables to run the deployment with. | [optional] 
**created_at** | **datetime** | When the deployment was created. | [optional] 
**updated_at** | **datetime** | When the deployment was last updated. | [optional] 
**stopped_at** | **datetime** | When the deployment was stopped. | [optional] 
**crn** | **str** | CRN of the model deployment. | [optional] 
**deployer** | [**ShortUser**](ShortUser.md) |  | [optional] 
**status** | **str** | The status of the model deployment. | [optional] 
**replicas** | **int** | Number of Replicas. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

