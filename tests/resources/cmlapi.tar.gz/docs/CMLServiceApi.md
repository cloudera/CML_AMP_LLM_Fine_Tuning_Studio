# cmlapi.CMLServiceApi

## Initializing Python Client

The cmlapi package provides the **default_client()** method to get the default client. The default_client method takes two arguments: url for the apiserver and cml_api_key for authentication. If no arguments are passed to the default_client method, the CDSW_API_URL and CDSW_APIV2_KEY environment variables are required.

```python
import cmlapi
api_url="http://workspacedemo.cloudera.com"
api_key="sfafagagirwyf37434848...."
api_client=cmlapi.default_client(url=api_url,cml_api_key=api_key)
api_client.list_projects()
api_client_withoutargs=cmlapi.default_client() # expects CDSW_API_URL and CDSW_APIV2_KEY environment variable
```

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_project_collaborator**](CMLServiceApi.md#add_project_collaborator) | **PUT** /api/v2/projects/{project_id}/collaborators/{username} | Add a project collaborator
[**batch_list_projects**](CMLServiceApi.md#batch_list_projects) | **GET** /api/v2/projects/batch | Return a list of projects given a list of project IDs. This method will only return projects that the calling user has access to, and can be used in situations where information about a subset of projects (like project names) is needed.
[**create_application**](CMLServiceApi.md#create_application) | **POST** /api/v2/projects/{project_id}/applications | Create an application and implicitly start it immediately.
[**create_experiment**](CMLServiceApi.md#create_experiment) | **POST** /api/v2/projects/{project_id}/experiments | Create an experiment.
[**create_experiment_run**](CMLServiceApi.md#create_experiment_run) | **POST** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs | Create a run for an experiment.
[**create_job**](CMLServiceApi.md#create_job) | **POST** /api/v2/projects/{project_id}/jobs | Create a new job.
[**create_job_run**](CMLServiceApi.md#create_job_run) | **POST** /api/v2/projects/{project_id}/jobs/{job_id}/runs | Create and start a new job run for a job.
[**create_model**](CMLServiceApi.md#create_model) | **POST** /api/v2/projects/{project_id}/models | Create a model.
[**create_model_build**](CMLServiceApi.md#create_model_build) | **POST** /api/v2/projects/{project_id}/models/{model_id}/builds | Create a model build.
[**create_model_deployment**](CMLServiceApi.md#create_model_deployment) | **POST** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id}/deployments | Create a model deployment.
[**create_project**](CMLServiceApi.md#create_project) | **POST** /api/v2/projects | Create a new project.
[**create_registered_model**](CMLServiceApi.md#create_registered_model) | **POST** /api/v2/registry/models | Register a model.
[**create_runtime_repo**](CMLServiceApi.md#create_runtime_repo) | **POST** /api/v2/runtimerepos | Create a  Runtime repo.
[**create_team**](CMLServiceApi.md#create_team) | **POST** /api/v2/site/teams | Create a team.
[**create_v2_key**](CMLServiceApi.md#create_v2_key) | **POST** /api/v2/users/{username}/v2_keys | Create API V2 key
[**delete_application**](CMLServiceApi.md#delete_application) | **DELETE** /api/v2/projects/{project_id}/applications/{application_id} | Delete an application.
[**delete_experiment**](CMLServiceApi.md#delete_experiment) | **DELETE** /api/v2/projects/{project_id}/experiments/{experiment_id} | Delete an experiment that belongs to an experiment id.
[**delete_experiment_run**](CMLServiceApi.md#delete_experiment_run) | **DELETE** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs/{run_id} | Delete an experiment run.
[**delete_experiment_run_batch**](CMLServiceApi.md#delete_experiment_run_batch) | **POST** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs/{run_id}:deletebatch | Bulk delete an experiment run details like metrics, params, tags in one request.
[**delete_job**](CMLServiceApi.md#delete_job) | **DELETE** /api/v2/projects/{project_id}/jobs/{job_id} | Deletes a job.
[**delete_model**](CMLServiceApi.md#delete_model) | **DELETE** /api/v2/projects/{project_id}/models/{model_id} | Delete a model.
[**delete_model_build**](CMLServiceApi.md#delete_model_build) | **DELETE** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id} | Delete a model build.
[**delete_project**](CMLServiceApi.md#delete_project) | **DELETE** /api/v2/projects/{project_id} | Delete a project.
[**delete_project_collaborator**](CMLServiceApi.md#delete_project_collaborator) | **DELETE** /api/v2/projects/{project_id}/collaborators/{username} | Delete a project collaborator
[**delete_project_file**](CMLServiceApi.md#delete_project_file) | **DELETE** /api/v2/projects/{project_id}/files/{path} | Delete a file or directory.
[**delete_registered_model**](CMLServiceApi.md#delete_registered_model) | **DELETE** /api/v2/registry/models/{model_id} | Unregister a model deletes a model.
[**delete_registered_model_version**](CMLServiceApi.md#delete_registered_model_version) | **DELETE** /api/v2/registry/models/{model_id}/versions/{version_id} | Unregister a model version.
[**delete_runtime_repo**](CMLServiceApi.md#delete_runtime_repo) | **DELETE** /api/v2/runtimerepos/{runtime_repo_id} | Delete a Runtime repo.
[**delete_team**](CMLServiceApi.md#delete_team) | **DELETE** /api/v2/teams/{team_name} | Delete a team.
[**delete_v2_key**](CMLServiceApi.md#delete_v2_key) | **DELETE** /api/v2/users/{username}/v2_keys/{key_id} | Delete an API V2 key
[**delete_v2_keys**](CMLServiceApi.md#delete_v2_keys) | **DELETE** /api/v2/users/{username}/v2_keys | Delete all API V2 keys
[**disable_engines**](CMLServiceApi.md#disable_engines) | **POST** /api/v2/site/config:update | Disable engines
[**download_project_file**](CMLServiceApi.md#download_project_file) | **POST** /api/v2/projects/{project_id}/files/{path}:download | download a project file
[**get_application**](CMLServiceApi.md#get_application) | **GET** /api/v2/projects/{project_id}/applications/{application_id} | Get an application.
[**get_experiment**](CMLServiceApi.md#get_experiment) | **GET** /api/v2/projects/{project_id}/experiments/{experiment_id} | Return one experiment.
[**get_experiment_run**](CMLServiceApi.md#get_experiment_run) | **GET** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs/{run_id} | Get metadata, metrics, params, tags and artifacts for a run. In the case where multiple metrics with the same key are logged for a run, return only the value with the latest timestamp. If there are multiple values with the latest timestamp, return the maximum of these values.
[**get_experiment_run_metrics**](CMLServiceApi.md#get_experiment_run_metrics) | **GET** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs/{run_id}/metrics/{metric_key} | Gets the all the recorded metrics for the key for a given run.
[**get_job**](CMLServiceApi.md#get_job) | **GET** /api/v2/projects/{project_id}/jobs/{job_id} | Return one job.
[**get_job_run**](CMLServiceApi.md#get_job_run) | **GET** /api/v2/projects/{project_id}/jobs/{job_id}/runs/{run_id} | Gets a job run.
[**get_model**](CMLServiceApi.md#get_model) | **GET** /api/v2/projects/{project_id}/models/{model_id} | Get a model.
[**get_model_build**](CMLServiceApi.md#get_model_build) | **GET** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id} | Get a model build.
[**get_model_deployment**](CMLServiceApi.md#get_model_deployment) | **GET** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id}/deployments/{deployment_id} | Get a model deployment.
[**get_project**](CMLServiceApi.md#get_project) | **GET** /api/v2/projects/{project_id} | Return one project.
[**get_registered_model**](CMLServiceApi.md#get_registered_model) | **GET** /api/v2/registry/models/{model_id} | Get a registered model.
[**get_registered_model_version**](CMLServiceApi.md#get_registered_model_version) | **GET** /api/v2/registry/models/{model_id}/versions/{version_id} | Get a registered model version
[**get_short_user_by_id**](CMLServiceApi.md#get_short_user_by_id) | **GET** /api/v2/users/{user_id} | 
[**get_time_series**](CMLServiceApi.md#get_time_series) | **GET** /api/v2/ts_data | Return the time series data for the requested resource or property.
[**handle_custom_runtime_upload**](CMLServiceApi.md#handle_custom_runtime_upload) | **POST** /api/v2/runtimeaddons/custom | Create a new Custom Runtime Addon from an uploaded tarball
[**list_all_accelerator_node_labels**](CMLServiceApi.md#list_all_accelerator_node_labels) | **GET** /api/v2/nodelabels | List all Accelerator Node Label
[**list_all_experiments**](CMLServiceApi.md#list_all_experiments) | **GET** /api/v2/experiments | Lists all experiments that belong to a user across all projects.
[**list_all_jobs**](CMLServiceApi.md#list_all_jobs) | **GET** /api/v2/jobs | Returns all jobs a user has access to.
[**list_all_models**](CMLServiceApi.md#list_all_models) | **GET** /api/v2/models | List all models that belong to a user across all projects.
[**list_all_run_as_machine_user_collaborators**](CMLServiceApi.md#list_all_run_as_machine_user_collaborators) | **GET** /api/v2/projects/{project_id}/machineusers | 
[**list_applications**](CMLServiceApi.md#list_applications) | **GET** /api/v2/projects/{project_id}/applications | List applications, optionally filtered, sorted, and paginated.
[**list_experiment_runs**](CMLServiceApi.md#list_experiment_runs) | **GET** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs | Returns a list of Runs that belong to an experiment.
[**list_experiments**](CMLServiceApi.md#list_experiments) | **GET** /api/v2/projects/{project_id}/experiments | List all experiments in a given project.
[**list_groups_quota**](CMLServiceApi.md#list_groups_quota) | **GET** /api/v2/groupsquota | Return all the groups and its quotas based on the context. Admin gets all the groups details.
[**list_job_runs**](CMLServiceApi.md#list_job_runs) | **GET** /api/v2/projects/{project_id}/jobs/{job_id}/runs | Lists job runs, optionally filtered, sorted, and paginated.
[**list_jobs**](CMLServiceApi.md#list_jobs) | **GET** /api/v2/projects/{project_id}/jobs | Returns all jobs, optionally filtered, sorted, and paginated.
[**list_model_builds**](CMLServiceApi.md#list_model_builds) | **GET** /api/v2/projects/{project_id}/models/{model_id}/builds | List model builds, optionally filtered, sorted, and paginated.
[**list_model_deployments**](CMLServiceApi.md#list_model_deployments) | **GET** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id}/deployments | List model deployments, optionally filtered, sorted, and paginated.
[**list_models**](CMLServiceApi.md#list_models) | **GET** /api/v2/projects/{project_id}/models | List models, optionally filtered, sorted, and paginated.
[**list_news_feeds**](CMLServiceApi.md#list_news_feeds) | **GET** /api/v2/newsfeeds/{category} | List the newsfeeds, optionally filtered, sorted, and paginated.
[**list_project_collaborators**](CMLServiceApi.md#list_project_collaborators) | **GET** /api/v2/projects/{project_id}/collaborators | List project collaborators.
[**list_project_files**](CMLServiceApi.md#list_project_files) | **GET** /api/v2/projects/{project_id}/files/{path} | List files/subdirectories at a specified path
[**list_project_names**](CMLServiceApi.md#list_project_names) | **GET** /api/v2/projectnames | Return all the project names the user has access to, optionally filtered, sorted, and paginated.
[**list_projects**](CMLServiceApi.md#list_projects) | **GET** /api/v2/projects | Return all projects, optionally filtered, sorted, and paginated.
[**list_registered_models**](CMLServiceApi.md#list_registered_models) | **GET** /api/v2/registry/models | List registered models.
[**list_runtime_addons**](CMLServiceApi.md#list_runtime_addons) | **GET** /api/v2/runtimeaddons | List the available runtime addons, optionally filtered, sorted, and paginated.
[**list_runtime_repos**](CMLServiceApi.md#list_runtime_repos) | **GET** /api/v2/runtimerepos | List Runtime repos.
[**list_runtimes**](CMLServiceApi.md#list_runtimes) | **GET** /api/v2/runtimes | List the available runtimes, optionally filtered, sorted, and paginated.
[**list_usage**](CMLServiceApi.md#list_usage) | **GET** /api/v2/usage | Return the new usage view based on the caller context, optionally filtered, sorted, and paginated.
[**list_users_quota**](CMLServiceApi.md#list_users_quota) | **GET** /api/v2/usersquota | Return all the user names and quotas based on the context. Admin gets all the users details.
[**list_v2_keys**](CMLServiceApi.md#list_v2_keys) | **GET** /api/v2/users/{username}/v2_keys | Get all API V2 keys
[**list_workload_status**](CMLServiceApi.md#list_workload_status) | **GET** /api/v2/workloadstatus | Return the workload statuses.
[**list_workload_types**](CMLServiceApi.md#list_workload_types) | **GET** /api/v2/workloadtypes | Return the workload types.
[**log_experiment_run_batch**](CMLServiceApi.md#log_experiment_run_batch) | **POST** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs/{run_id}:logbatch | Bulk update an experiment run details like metrics, params, tags in one request.
[**register_custom_runtime**](CMLServiceApi.md#register_custom_runtime) | **POST** /api/v2/runtimes | Register a runtime, given the URL to the image in the docker registry
[**restart_application**](CMLServiceApi.md#restart_application) | **POST** /api/v2/projects/{project_id}/applications/{application_id}:restart | Start an application.
[**restart_model_deployment**](CMLServiceApi.md#restart_model_deployment) | **POST** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id}/deployments/{deployment_id}:restart | Restart a model deployment.
[**rotate_v1_key**](CMLServiceApi.md#rotate_v1_key) | **POST** /api/v2/users/{username}/v1_key:rotate | Rotate API V1 key
[**stop_application**](CMLServiceApi.md#stop_application) | **POST** /api/v2/projects/{project_id}/applications/{application_id}:stop | Stop an application.
[**stop_job_run**](CMLServiceApi.md#stop_job_run) | **POST** /api/v2/projects/{project_id}/jobs/{job_id}/runs/{run_id}:stop | Stops a job run. Encoded as a custom method.
[**stop_model_deployment**](CMLServiceApi.md#stop_model_deployment) | **POST** /api/v2/projects/{project_id}/models/{model_id}/builds/{build_id}/deployments/{deployment_id}:stop | Stop a model deployment.
[**update_accelerator_labels_admin_config**](CMLServiceApi.md#update_accelerator_labels_admin_config) | **PATCH** /api/v2/nodelabels/config | Update admin_config_max_per_workload in Node Labels
[**update_application**](CMLServiceApi.md#update_application) | **PATCH** /api/v2/projects/{project_id}/applications/{application.id} | Update an application
[**update_experiment**](CMLServiceApi.md#update_experiment) | **PATCH** /api/v2/projects/{experiment.project_id}/experiments/{experiment.id} | Update an existing experiment.
[**update_experiment_run**](CMLServiceApi.md#update_experiment_run) | **PATCH** /api/v2/projects/{project_id}/experiments/{experiment_id}/runs/{run.id} | Update an experiment run.
[**update_job**](CMLServiceApi.md#update_job) | **PATCH** /api/v2/projects/{project_id}/jobs/{job.id} | Updates a job.
[**update_model**](CMLServiceApi.md#update_model) | **PATCH** /api/v2/projects/{project_id}/models/{model.id} | Update a model.
[**update_project**](CMLServiceApi.md#update_project) | **PATCH** /api/v2/projects/{project.id} | Update an existing project.
[**update_project_file_metadata**](CMLServiceApi.md#update_project_file_metadata) | **PATCH** /api/v2/projects/{project_id}/files/{path} | Update file metadata, such as renaming.
[**update_registered_model**](CMLServiceApi.md#update_registered_model) | **PATCH** /api/v2/registry/models | Update a Registered model.
[**update_registered_model_version**](CMLServiceApi.md#update_registered_model_version) | **PATCH** /api/v2/registry/models/{model_id} | Update a Registered model version.
[**update_runtime_addon_status**](CMLServiceApi.md#update_runtime_addon_status) | **POST** /api/v2/runtimeaddons:updatestatus | Update runtime addons
[**update_runtime_repo**](CMLServiceApi.md#update_runtime_repo) | **PATCH** /api/v2/runtimerepos/{runtimerepo.id} | Update a Runtime repo.
[**update_runtime_status**](CMLServiceApi.md#update_runtime_status) | **POST** /api/v2/runtimes:update | Update the status of selected runtimes
[**upload_file**](CMLServiceApi.md#upload_file) | **POST** /api/v2/projects/{project_id}/files | upload a file as a multi-part upload
[**validate_custom_runtime**](CMLServiceApi.md#validate_custom_runtime) | **GET** /api/v2/runtimes:validate | Validate a runtime, given the URL to the image in the docker registry

# **add_project_collaborator**
> AddProjectCollaboratorResponse add_project_collaborator(body, project_id, username)

Add a project collaborator

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.AddProjectCollaboratorRequest() # AddProjectCollaboratorRequest | 
project_id = 'project_id_example' # str | The identifier of the project.
username = 'username_example' # str | The username of the collaborator to add.

try:
    # Add a project collaborator
    api_response = api_instance.add_project_collaborator(body, project_id, username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->add_project_collaborator: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AddProjectCollaboratorRequest**](AddProjectCollaboratorRequest.md)|  | 
 **project_id** | **str**| The identifier of the project. | 
 **username** | **str**| The username of the collaborator to add. | 

### Return type

[**AddProjectCollaboratorResponse**](AddProjectCollaboratorResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **batch_list_projects**
> BatchListProjectsResponse batch_list_projects(project_ids=project_ids)

Return a list of projects given a list of project IDs. This method will only return projects that the calling user has access to, and can be used in situations where information about a subset of projects (like project names) is needed.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_ids = ['project_ids_example'] # list[str] | The list of project IDs to return projects for. (optional)

try:
    # Return a list of projects given a list of project IDs. This method will only return projects that the calling user has access to, and can be used in situations where information about a subset of projects (like project names) is needed.
    api_response = api_instance.batch_list_projects(project_ids=project_ids)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->batch_list_projects: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_ids** | [**list[str]**](str.md)| The list of project IDs to return projects for. | [optional] 

### Return type

[**BatchListProjectsResponse**](BatchListProjectsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_application**
> Application create_application(body, project_id)

Create an application and implicitly start it immediately.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateApplicationRequest() # CreateApplicationRequest | 
project_id = 'project_id_example' # str | The project's identifier

try:
    # Create an application and implicitly start it immediately.
    api_response = api_instance.create_application(body, project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_application: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateApplicationRequest**](CreateApplicationRequest.md)|  | 
 **project_id** | **str**| The project&#x27;s identifier | 

### Return type

[**Application**](Application.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_experiment**
> Experiment create_experiment(body, project_id)

Create an experiment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateExperimentRequest() # CreateExperimentRequest | 
project_id = 'project_id_example' # str | 

try:
    # Create an experiment.
    api_response = api_instance.create_experiment(body, project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_experiment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateExperimentRequest**](CreateExperimentRequest.md)|  | 
 **project_id** | **str**|  | 

### Return type

[**Experiment**](Experiment.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_experiment_run**
> ExperimentRun create_experiment_run(body, project_id, experiment_id)

Create a run for an experiment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateExperimentRunRequest() # CreateExperimentRunRequest | 
project_id = 'project_id_example' # str | 
experiment_id = 'experiment_id_example' # str | ID of the associated experiment.

try:
    # Create a run for an experiment.
    api_response = api_instance.create_experiment_run(body, project_id, experiment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_experiment_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateExperimentRunRequest**](CreateExperimentRunRequest.md)|  | 
 **project_id** | **str**|  | 
 **experiment_id** | **str**| ID of the associated experiment. | 

### Return type

[**ExperimentRun**](ExperimentRun.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_job**
> Job create_job(body, project_id)

Create a new job.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateJobRequest() # CreateJobRequest | 
project_id = 'project_id_example' # str | ID of the project containing the job.

try:
    # Create a new job.
    api_response = api_instance.create_job(body, project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_job: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateJobRequest**](CreateJobRequest.md)|  | 
 **project_id** | **str**| ID of the project containing the job. | 

### Return type

[**Job**](Job.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_job_run**
> JobRun create_job_run(body, project_id, job_id)

Create and start a new job run for a job.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateJobRunRequest() # CreateJobRunRequest | 
project_id = 'project_id_example' # str | ID of the project containing the job.
job_id = 'job_id_example' # str | The job ID to create a new job run for.

try:
    # Create and start a new job run for a job.
    api_response = api_instance.create_job_run(body, project_id, job_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_job_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateJobRunRequest**](CreateJobRunRequest.md)|  | 
 **project_id** | **str**| ID of the project containing the job. | 
 **job_id** | **str**| The job ID to create a new job run for. | 

### Return type

[**JobRun**](JobRun.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_model**
> Model create_model(body, project_id)

Create a model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateModelRequest() # CreateModelRequest | 
project_id = 'project_id_example' # str | ID of the project containing the model.

try:
    # Create a model.
    api_response = api_instance.create_model(body, project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateModelRequest**](CreateModelRequest.md)|  | 
 **project_id** | **str**| ID of the project containing the model. | 

### Return type

[**Model**](Model.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_model_build**
> ModelBuild create_model_build(body, project_id, model_id)

Create a model build.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateModelBuildRequest() # CreateModelBuildRequest | 
project_id = 'project_id_example' # str | ID of the project containing the model build.
model_id = 'model_id_example' # str | The ID of the model that will the build.

try:
    # Create a model build.
    api_response = api_instance.create_model_build(body, project_id, model_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_model_build: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateModelBuildRequest**](CreateModelBuildRequest.md)|  | 
 **project_id** | **str**| ID of the project containing the model build. | 
 **model_id** | **str**| The ID of the model that will the build. | 

### Return type

[**ModelBuild**](ModelBuild.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_model_deployment**
> ModelDeployment create_model_deployment(body, project_id, model_id, build_id)

Create a model deployment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateModelDeploymentRequest() # CreateModelDeploymentRequest | 
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model to deploy.
build_id = 'build_id_example' # str | ID of the model build to deploy.

try:
    # Create a model deployment.
    api_response = api_instance.create_model_deployment(body, project_id, model_id, build_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_model_deployment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateModelDeploymentRequest**](CreateModelDeploymentRequest.md)|  | 
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model to deploy. | 
 **build_id** | **str**| ID of the model build to deploy. | 

### Return type

[**ModelDeployment**](ModelDeployment.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_project**
> Project create_project(body)

Create a new project.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateProjectRequest() # CreateProjectRequest | 

try:
    # Create a new project.
    api_response = api_instance.create_project(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_project: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateProjectRequest**](CreateProjectRequest.md)|  | 

### Return type

[**Project**](Project.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_registered_model**
> RegisteredModel create_registered_model(body)

Register a model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateRegisteredModelRequest() # CreateRegisteredModelRequest | 

try:
    # Register a model.
    api_response = api_instance.create_registered_model(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_registered_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateRegisteredModelRequest**](CreateRegisteredModelRequest.md)|  | 

### Return type

[**RegisteredModel**](RegisteredModel.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_runtime_repo**
> RuntimeRepo create_runtime_repo(body)

Create a  Runtime repo.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateRuntimeRepoRequest() # CreateRuntimeRepoRequest | 

try:
    # Create a  Runtime repo.
    api_response = api_instance.create_runtime_repo(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_runtime_repo: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateRuntimeRepoRequest**](CreateRuntimeRepoRequest.md)|  | 

### Return type

[**RuntimeRepo**](RuntimeRepo.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_team**
> Team create_team(body)

Create a team.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateTeamRequest() # CreateTeamRequest | 

try:
    # Create a team.
    api_response = api_instance.create_team(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_team: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateTeamRequest**](CreateTeamRequest.md)|  | 

### Return type

[**Team**](Team.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_v2_key**
> CreateV2KeyResponse create_v2_key(body, username)

Create API V2 key

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.CreateV2KeyRequest() # CreateV2KeyRequest | 
username = 'username_example' # str | username of the user whose V2 key you want to create

try:
    # Create API V2 key
    api_response = api_instance.create_v2_key(body, username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->create_v2_key: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateV2KeyRequest**](CreateV2KeyRequest.md)|  | 
 **username** | **str**| username of the user whose V2 key you want to create | 

### Return type

[**CreateV2KeyResponse**](CreateV2KeyResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_application**
> DeleteApplicationResponse delete_application(project_id, application_id)

Delete an application.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The public project identifier
application_id = 'application_id_example' # str | The public application identifier

try:
    # Delete an application.
    api_response = api_instance.delete_application(project_id, application_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_application: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The public project identifier | 
 **application_id** | **str**| The public application identifier | 

### Return type

[**DeleteApplicationResponse**](DeleteApplicationResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_experiment**
> DeleteExperimentResponse delete_experiment(project_id, experiment_id)

Delete an experiment that belongs to an experiment id.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | 
experiment_id = 'experiment_id_example' # str | 

try:
    # Delete an experiment that belongs to an experiment id.
    api_response = api_instance.delete_experiment(project_id, experiment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_experiment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  | 
 **experiment_id** | **str**|  | 

### Return type

[**DeleteExperimentResponse**](DeleteExperimentResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_experiment_run**
> DeleteExperimentRunResponse delete_experiment_run(project_id, experiment_id, run_id)

Delete an experiment run.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project the experiment run lives in.
experiment_id = 'experiment_id_example' # str | The experiment the run is a part of.
run_id = 'run_id_example' # str | The ID of the run to delete.

try:
    # Delete an experiment run.
    api_response = api_instance.delete_experiment_run(project_id, experiment_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_experiment_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project the experiment run lives in. | 
 **experiment_id** | **str**| The experiment the run is a part of. | 
 **run_id** | **str**| The ID of the run to delete. | 

### Return type

[**DeleteExperimentRunResponse**](DeleteExperimentRunResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_experiment_run_batch**
> DeleteExperimentRunBatchResponse delete_experiment_run_batch(body, project_id, experiment_id, run_id)

Bulk delete an experiment run details like metrics, params, tags in one request.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.DeleteExperimentRunBatchRequest() # DeleteExperimentRunBatchRequest | 
project_id = 'project_id_example' # str | 
experiment_id = 'experiment_id_example' # str | 
run_id = 'run_id_example' # str | ID of the ExperimentRun to log under

try:
    # Bulk delete an experiment run details like metrics, params, tags in one request.
    api_response = api_instance.delete_experiment_run_batch(body, project_id, experiment_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_experiment_run_batch: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DeleteExperimentRunBatchRequest**](DeleteExperimentRunBatchRequest.md)|  | 
 **project_id** | **str**|  | 
 **experiment_id** | **str**|  | 
 **run_id** | **str**| ID of the ExperimentRun to log under | 

### Return type

[**DeleteExperimentRunBatchResponse**](DeleteExperimentRunBatchResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_job**
> DeleteJobResponse delete_job(project_id, job_id)

Deletes a job.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | the public project identifier
job_id = 'job_id_example' # str | The public job identifier

try:
    # Deletes a job.
    api_response = api_instance.delete_job(project_id, job_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_job: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| the public project identifier | 
 **job_id** | **str**| The public job identifier | 

### Return type

[**DeleteJobResponse**](DeleteJobResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_model**
> DeleteModelResponse delete_model(project_id, model_id)

Delete a model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model to delete.

try:
    # Delete a model.
    api_response = api_instance.delete_model(project_id, model_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model to delete. | 

### Return type

[**DeleteModelResponse**](DeleteModelResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_model_build**
> DeleteModelBuildResponse delete_model_build(project_id, model_id, build_id)

Delete a model build.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model containing the build.
build_id = 'build_id_example' # str | ID of the build to delete.

try:
    # Delete a model build.
    api_response = api_instance.delete_model_build(project_id, model_id, build_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_model_build: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model containing the build. | 
 **build_id** | **str**| ID of the build to delete. | 

### Return type

[**DeleteModelBuildResponse**](DeleteModelBuildResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_project**
> DeleteProjectResponse delete_project(project_id)

Delete a project.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project's identifier

try:
    # Delete a project.
    api_response = api_instance.delete_project(project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_project: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project&#x27;s identifier | 

### Return type

[**DeleteProjectResponse**](DeleteProjectResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_project_collaborator**
> DeleteProjectCollaboratorResponse delete_project_collaborator(project_id, username)

Delete a project collaborator

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The identifier of the project.
username = 'username_example' # str | The username of the collaborator to add.

try:
    # Delete a project collaborator
    api_response = api_instance.delete_project_collaborator(project_id, username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_project_collaborator: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The identifier of the project. | 
 **username** | **str**| The username of the collaborator to add. | 

### Return type

[**DeleteProjectCollaboratorResponse**](DeleteProjectCollaboratorResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_project_file**
> DeleteProjectFileResponse delete_project_file(project_id, path)

Delete a file or directory.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The identifier of the project that contains the file or directory.
path = 'path_example' # str | The path to the file or directory to delete.

try:
    # Delete a file or directory.
    api_response = api_instance.delete_project_file(project_id, path)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_project_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The identifier of the project that contains the file or directory. | 
 **path** | **str**| The path to the file or directory to delete. | 

### Return type

[**DeleteProjectFileResponse**](DeleteProjectFileResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_registered_model**
> DeleteRegisteredModelResponse delete_registered_model(model_id)

Unregister a model deletes a model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
model_id = 'model_id_example' # str | Model ID.

try:
    # Unregister a model deletes a model.
    api_response = api_instance.delete_registered_model(model_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_registered_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**| Model ID. | 

### Return type

[**DeleteRegisteredModelResponse**](DeleteRegisteredModelResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_registered_model_version**
> DeleteRegisteredModelVersionResponse delete_registered_model_version(model_id, version_id)

Unregister a model version.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
model_id = 'model_id_example' # str | Model ID.
version_id = 'version_id_example' # str | Model version ID.

try:
    # Unregister a model version.
    api_response = api_instance.delete_registered_model_version(model_id, version_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_registered_model_version: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**| Model ID. | 
 **version_id** | **str**| Model version ID. | 

### Return type

[**DeleteRegisteredModelVersionResponse**](DeleteRegisteredModelVersionResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_runtime_repo**
> DeleteRuntimeRepoResponse delete_runtime_repo(runtime_repo_id)

Delete a Runtime repo.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
runtime_repo_id = 56 # int | the id of the Runtime Repo to delete

try:
    # Delete a Runtime repo.
    api_response = api_instance.delete_runtime_repo(runtime_repo_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_runtime_repo: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **runtime_repo_id** | **int**| the id of the Runtime Repo to delete | 

### Return type

[**DeleteRuntimeRepoResponse**](DeleteRuntimeRepoResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_team**
> DeleteTeamResponse delete_team(team_name)

Delete a team.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
team_name = 'team_name_example' # str | name of the team you want to delete

try:
    # Delete a team.
    api_response = api_instance.delete_team(team_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_team: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **team_name** | **str**| name of the team you want to delete | 

### Return type

[**DeleteTeamResponse**](DeleteTeamResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_v2_key**
> DeleteV2KeyResponse delete_v2_key(username, key_id)

Delete an API V2 key

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
username = 'username_example' # str | username of the user whose V2 key you want to delete
key_id = 'key_id_example' # str | ID of the V2 key

try:
    # Delete an API V2 key
    api_response = api_instance.delete_v2_key(username, key_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_v2_key: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| username of the user whose V2 key you want to delete | 
 **key_id** | **str**| ID of the V2 key | 

### Return type

[**DeleteV2KeyResponse**](DeleteV2KeyResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_v2_keys**
> DeleteV2KeysResponse delete_v2_keys(username)

Delete all API V2 keys

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
username = 'username_example' # str | username of the user whose V2 keys you want to delete

try:
    # Delete all API V2 keys
    api_response = api_instance.delete_v2_keys(username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->delete_v2_keys: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| username of the user whose V2 keys you want to delete | 

### Return type

[**DeleteV2KeysResponse**](DeleteV2KeysResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **disable_engines**
> DisableEnginesResponse disable_engines(body)

Disable engines

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.DisableEnginesRequest() # DisableEnginesRequest | 

try:
    # Disable engines
    api_response = api_instance.disable_engines(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->disable_engines: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DisableEnginesRequest**](DisableEnginesRequest.md)|  | 

### Return type

[**DisableEnginesResponse**](DisableEnginesResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **download_project_file**
> download_project_file(project_id, path)

download a project file

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project this model belongs to.
path = 'path_example' # str | The path of the file to download

try:
    # download a project file
    api_instance.download_project_file(project_id, path)
except ApiException as e:
    print("Exception when calling CMLServiceApi->download_project_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project this model belongs to. | 
 **path** | **str**| The path of the file to download | 

### Return type

void (empty response body)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_application**
> Application get_application(project_id, application_id)

Get an application.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The public project identifier
application_id = 'application_id_example' # str | The public application identifier

try:
    # Get an application.
    api_response = api_instance.get_application(project_id, application_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_application: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The public project identifier | 
 **application_id** | **str**| The public application identifier | 

### Return type

[**Application**](Application.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_experiment**
> Experiment get_experiment(project_id, experiment_id)

Return one experiment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | 
experiment_id = 'experiment_id_example' # str | ID of the associated experiment.

try:
    # Return one experiment.
    api_response = api_instance.get_experiment(project_id, experiment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_experiment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  | 
 **experiment_id** | **str**| ID of the associated experiment. | 

### Return type

[**Experiment**](Experiment.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_experiment_run**
> ExperimentRun get_experiment_run(project_id, experiment_id, run_id)

Get metadata, metrics, params, tags and artifacts for a run. In the case where multiple metrics with the same key are logged for a run, return only the value with the latest timestamp. If there are multiple values with the latest timestamp, return the maximum of these values.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | 
experiment_id = 'experiment_id_example' # str | ID of the associated experiment.
run_id = 'run_id_example' # str | ID of the ExperimentRun to fetch. Must be provided.

try:
    # Get metadata, metrics, params, tags and artifacts for a run. In the case where multiple metrics with the same key are logged for a run, return only the value with the latest timestamp. If there are multiple values with the latest timestamp, return the maximum of these values.
    api_response = api_instance.get_experiment_run(project_id, experiment_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_experiment_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  | 
 **experiment_id** | **str**| ID of the associated experiment. | 
 **run_id** | **str**| ID of the ExperimentRun to fetch. Must be provided. | 

### Return type

[**ExperimentRun**](ExperimentRun.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_experiment_run_metrics**
> GetExperimentRunMetricsResponse get_experiment_run_metrics(project_id, experiment_id, run_id, metric_key)

Gets the all the recorded metrics for the key for a given run.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | Project ID
experiment_id = 'experiment_id_example' # str | Experiment ID the run belongs to
run_id = 'run_id_example' # str | ID of the ExperimentRun
metric_key = 'metric_key_example' # str | metric key name.

try:
    # Gets the all the recorded metrics for the key for a given run.
    api_response = api_instance.get_experiment_run_metrics(project_id, experiment_id, run_id, metric_key)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_experiment_run_metrics: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| Project ID | 
 **experiment_id** | **str**| Experiment ID the run belongs to | 
 **run_id** | **str**| ID of the ExperimentRun | 
 **metric_key** | **str**| metric key name. | 

### Return type

[**GetExperimentRunMetricsResponse**](GetExperimentRunMetricsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_job**
> Job get_job(project_id, job_id)

Return one job.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The public project identifier
job_id = 'job_id_example' # str | The public job identifier

try:
    # Return one job.
    api_response = api_instance.get_job(project_id, job_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_job: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The public project identifier | 
 **job_id** | **str**| The public job identifier | 

### Return type

[**Job**](Job.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_job_run**
> JobRun get_job_run(project_id, job_id, run_id)

Gets a job run.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the job.
job_id = 'job_id_example' # str | ID of the job containing the job run.
run_id = 'run_id_example' # str | ID of the job run to get.

try:
    # Gets a job run.
    api_response = api_instance.get_job_run(project_id, job_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_job_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the job. | 
 **job_id** | **str**| ID of the job containing the job run. | 
 **run_id** | **str**| ID of the job run to get. | 

### Return type

[**JobRun**](JobRun.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_model**
> Model get_model(project_id, model_id)

Get a model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project this model belongs to.
model_id = 'model_id_example' # str | The model's ID

try:
    # Get a model.
    api_response = api_instance.get_model(project_id, model_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project this model belongs to. | 
 **model_id** | **str**| The model&#x27;s ID | 

### Return type

[**Model**](Model.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_model_build**
> ModelBuild get_model_build(project_id, model_id, build_id, registered_model_version_id=registered_model_version_id)

Get a model build.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model containing the build.
build_id = 'build_id_example' # str | ID of the model build to get.
registered_model_version_id = 'registered_model_version_id_example' # str | ID of the registered model version. (optional)

try:
    # Get a model build.
    api_response = api_instance.get_model_build(project_id, model_id, build_id, registered_model_version_id=registered_model_version_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_model_build: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model containing the build. | 
 **build_id** | **str**| ID of the model build to get. | 
 **registered_model_version_id** | **str**| ID of the registered model version. | [optional] 

### Return type

[**ModelBuild**](ModelBuild.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_model_deployment**
> ModelDeployment get_model_deployment(project_id, model_id, build_id, deployment_id)

Get a model deployment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model containing the deployment.
build_id = 'build_id_example' # str | ID of the model build containing the deployment.
deployment_id = 'deployment_id_example' # str | ID of the model deployment to get.

try:
    # Get a model deployment.
    api_response = api_instance.get_model_deployment(project_id, model_id, build_id, deployment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_model_deployment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model containing the deployment. | 
 **build_id** | **str**| ID of the model build containing the deployment. | 
 **deployment_id** | **str**| ID of the model deployment to get. | 

### Return type

[**ModelDeployment**](ModelDeployment.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_project**
> Project get_project(project_id)

Return one project.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | Identifier for a project, in the form of a 19 digit string. Example: a1b2-c3d4-e5f6-g7h8

try:
    # Return one project.
    api_response = api_instance.get_project(project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_project: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| Identifier for a project, in the form of a 19 digit string. Example: a1b2-c3d4-e5f6-g7h8 | 

### Return type

[**Project**](Project.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_registered_model**
> RegisteredModel get_registered_model(model_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

Get a registered model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
model_id = 'model_id_example' # str | Model ID.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filters: earch_filter = {\"version_number\":\"3\"} search_filter = {\"creator_id\":\"<sso name or user name>\"} example: csso_mlengineer. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name script status updated_at]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. : supported sort=-created_at supported sort=-versions. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # Get a registered model.
    api_response = api_instance.get_registered_model(model_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_registered_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**| Model ID. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filters: earch_filter &#x3D; {\&quot;version_number\&quot;:\&quot;3\&quot;} search_filter &#x3D; {\&quot;creator_id\&quot;:\&quot;&lt;sso name or user name&gt;\&quot;} example: csso_mlengineer. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name script status updated_at]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. : supported sort&#x3D;-created_at supported sort&#x3D;-versions. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**RegisteredModel**](RegisteredModel.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_registered_model_version**
> RegisteredModelVersion get_registered_model_version(model_id, version_id)

Get a registered model version

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
model_id = 'model_id_example' # str | Model ID.
version_id = 'version_id_example' # str | Model version ID.

try:
    # Get a registered model version
    api_response = api_instance.get_registered_model_version(model_id, version_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_registered_model_version: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **model_id** | **str**| Model ID. | 
 **version_id** | **str**| Model version ID. | 

### Return type

[**RegisteredModelVersion**](RegisteredModelVersion.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_short_user_by_id**
> ShortUser get_short_user_by_id(user_id)



### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
user_id = 56 # int | 

try:
    api_response = api_instance.get_short_user_by_id(user_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_short_user_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **int**|  | 

### Return type

[**ShortUser**](ShortUser.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_time_series**
> TimeSeriesResponse get_time_series(search_filter=search_filter, page_token=page_token, multi_column_search_filter=multi_column_search_filter, time_range_search_filter=time_range_search_filter, series_type=series_type)

Return the time series data for the requested resource or property.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [name creator group project_name workload_type status]. For example:   search_filter={\"name\":\"My Session\",\"workload_type\":\"session\"}. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)
multi_column_search_filter = 'multi_column_search_filter_example' # str | Multi column search filter is an optional HTTP parameter to filter multiple columns. Supported Multi column search filter keys are: [project_or_workload_name]. For example:   multi_column_search_filter={\"project_or_workload_name\":\"name\"}. (optional)
time_range_search_filter = 'time_range_search_filter_example' # str | Time range search filter is an optional HTTP parameter to filter based on the time. Supported Time range search filters are: [created_time]. For example:   time_range_search_filter={\"created_time\":{\"min\":\"2023-12-11 21:06:51\",\"max\":\"2023-12-11 21:08:51\"}}. (optional)
series_type = 'series_type_example' # str | Type of the time series. Supported values are [cpu, memory, gpu]. (optional)

try:
    # Return the time series data for the requested resource or property.
    api_response = api_instance.get_time_series(search_filter=search_filter, page_token=page_token, multi_column_search_filter=multi_column_search_filter, time_range_search_filter=time_range_search_filter, series_type=series_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->get_time_series: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [name creator group project_name workload_type status]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;My Session\&quot;,\&quot;workload_type\&quot;:\&quot;session\&quot;}. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 
 **multi_column_search_filter** | **str**| Multi column search filter is an optional HTTP parameter to filter multiple columns. Supported Multi column search filter keys are: [project_or_workload_name]. For example:   multi_column_search_filter&#x3D;{\&quot;project_or_workload_name\&quot;:\&quot;name\&quot;}. | [optional] 
 **time_range_search_filter** | **str**| Time range search filter is an optional HTTP parameter to filter based on the time. Supported Time range search filters are: [created_time]. For example:   time_range_search_filter&#x3D;{\&quot;created_time\&quot;:{\&quot;min\&quot;:\&quot;2023-12-11 21:06:51\&quot;,\&quot;max\&quot;:\&quot;2023-12-11 21:08:51\&quot;}}. | [optional] 
 **series_type** | **str**| Type of the time series. Supported values are [cpu, memory, gpu]. | [optional] 

### Return type

[**TimeSeriesResponse**](TimeSeriesResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **handle_custom_runtime_upload**
> handle_custom_runtime_upload(metadata, tarball)

Create a new Custom Runtime Addon from an uploaded tarball

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
metadata = 'metadata_example' # str | 
tarball = 'tarball_example' # str | 

try:
    # Create a new Custom Runtime Addon from an uploaded tarball
    api_instance.handle_custom_runtime_upload(metadata, tarball)
except ApiException as e:
    print("Exception when calling CMLServiceApi->handle_custom_runtime_upload: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **metadata** | **str**|  | 
 **tarball** | **str**|  | 

### Return type

void (empty response body)


### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_all_accelerator_node_labels**
> ListAllAcceleratorsNodeLabelsResponse list_all_accelerator_node_labels(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List all Accelerator Node Label

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [id label_key]. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [id label_key].   sort=id. (optional)
page_size = 56 # int | page size of the response accelerator node labels list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # List all Accelerator Node Label
    api_response = api_instance.list_all_accelerator_node_labels(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_all_accelerator_node_labels: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [id label_key]. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [id label_key].   sort&#x3D;id. | [optional] 
 **page_size** | **int**| page size of the response accelerator node labels list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListAllAcceleratorsNodeLabelsResponse**](ListAllAcceleratorsNodeLabelsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_all_experiments**
> ListExperimentsResponse list_all_experiments(search_filter=search_filter, page_size=page_size, page_token=page_token)

Lists all experiments that belong to a user across all projects.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # Lists all experiments that belong to a user across all projects.
    api_response = api_instance.list_all_experiments(search_filter=search_filter, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_all_experiments: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListExperimentsResponse**](ListExperimentsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_all_jobs**
> ListJobsResponse list_all_jobs(search_filter=search_filter, page_size=page_size, page_token=page_token)

Returns all jobs a user has access to.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description kernel name paused script type]. For example:   search_filter={\"name\":\"foo\",\"creator.name\":\"bar\"},. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # Returns all jobs a user has access to.
    api_response = api_instance.list_all_jobs(search_filter=search_filter, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_all_jobs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description kernel name paused script type]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;foo\&quot;,\&quot;creator.name\&quot;:\&quot;bar\&quot;},. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListJobsResponse**](ListJobsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_all_models**
> ListModelsResponse list_all_models(search_filter=search_filter, page_size=page_size, page_token=page_token)

List all models that belong to a user across all projects.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str |  (optional)
page_size = 56 # int |  (optional)
page_token = 'page_token_example' # str |  (optional)

try:
    # List all models that belong to a user across all projects.
    api_response = api_instance.list_all_models(search_filter=search_filter, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_all_models: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**|  | [optional] 
 **page_size** | **int**|  | [optional] 
 **page_token** | **str**|  | [optional] 

### Return type

[**ListModelsResponse**](ListModelsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_all_run_as_machine_user_collaborators**
> ListAllRunAsMachineUserCollaboratorsResponse list_all_run_as_machine_user_collaborators(project_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)



### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | 
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. (optional)
page_size = 56 # int | page size of the response model build list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: []. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=. (optional)

try:
    api_response = api_instance.list_all_run_as_machine_user_collaborators(project_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_all_run_as_machine_user_collaborators: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. | [optional] 
 **page_size** | **int**| page size of the response model build list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: []. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;. | [optional] 

### Return type

[**ListAllRunAsMachineUserCollaboratorsResponse**](ListAllRunAsMachineUserCollaboratorsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_applications**
> ListApplicationsResponse list_applications(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List applications, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project's identifier
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [bypass_authentication creator.email creator.name creator.username description kernel name script status subdomain] where \"status\" can be one of the following: [running, stopping, stopped, starting, failed] For example:   search_filter = {\"status\":\"running\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name script status updated_at]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=-updated_at,name. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # List applications, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_applications(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_applications: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project&#x27;s identifier | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [bypass_authentication creator.email creator.name creator.username description kernel name script status subdomain] where \&quot;status\&quot; can be one of the following: [running, stopping, stopped, starting, failed] For example:   search_filter &#x3D; {\&quot;status\&quot;:\&quot;running\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name script status updated_at]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;-updated_at,name. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListApplicationsResponse**](ListApplicationsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_experiment_runs**
> ListExperimentRunsResponse list_experiment_runs(project_id, experiment_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)

Returns a list of Runs that belong to an experiment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project to list experiment runs in.
experiment_id = 'experiment_id_example' # str | Experiment ID to search over.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username name status]. Dynamic search key words are supported for experiment runs. Supported fields are [metrics tags params]. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username name start_time]. It also supports dynamic sort for metrics, tags and params. \"+\" means sort by ascending order, and \"-\" means sort by descending order. (optional)

try:
    # Returns a list of Runs that belong to an experiment.
    api_response = api_instance.list_experiment_runs(project_id, experiment_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_experiment_runs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project to list experiment runs in. | 
 **experiment_id** | **str**| Experiment ID to search over. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username name status]. Dynamic search key words are supported for experiment runs. Supported fields are [metrics tags params]. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username name start_time]. It also supports dynamic sort for metrics, tags and params. \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. | [optional] 

### Return type

[**ListExperimentRunsResponse**](ListExperimentRunsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_experiments**
> ListExperimentsResponse list_experiments(project_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)

List all experiments in a given project.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | 
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. (optional)

try:
    # List all experiments in a given project.
    api_response = api_instance.list_experiments(project_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_experiments: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**|  | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. | [optional] 

### Return type

[**ListExperimentsResponse**](ListExperimentsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_groups_quota**
> ListGroupsQuotaResponse list_groups_quota(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

Return all the groups and its quotas based on the context. Admin gets all the groups details.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [banned deactivated]. For example:   search_filter={\"deactivated\":\"false\",\"banned\":\"false\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [username]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=username. (optional)
page_size = 56 # int | page size of the response runtime repo list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # Return all the groups and its quotas based on the context. Admin gets all the groups details.
    api_response = api_instance.list_groups_quota(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_groups_quota: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [banned deactivated]. For example:   search_filter&#x3D;{\&quot;deactivated\&quot;:\&quot;false\&quot;,\&quot;banned\&quot;:\&quot;false\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [username]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;username. | [optional] 
 **page_size** | **int**| page size of the response runtime repo list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListGroupsQuotaResponse**](ListGroupsQuotaResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_job_runs**
> ListJobRunsResponse list_job_runs(project_id, job_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

Lists job runs, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the job.
job_id = 'job_id_example' # str | ID of the job containing the job runs.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description kernel name paused script type], where \"status\" can be one of the following: [scheduling, running, stopping, stopped, succeeded, failed, timedout] For example:   search_filter={\"status\":\"running\",\"id\": \"1\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name paused script type updated_at]\" where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=-updated_at,+name. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # Lists job runs, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_job_runs(project_id, job_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_job_runs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the job. | 
 **job_id** | **str**| ID of the job containing the job runs. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description kernel name paused script type], where \&quot;status\&quot; can be one of the following: [scheduling, running, stopping, stopped, succeeded, failed, timedout] For example:   search_filter&#x3D;{\&quot;status\&quot;:\&quot;running\&quot;,\&quot;id\&quot;: \&quot;1\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name paused script type updated_at]\&quot; where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;-updated_at,+name. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListJobRunsResponse**](ListJobRunsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_jobs**
> ListJobsResponse list_jobs(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

Returns all jobs, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project's identifier
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description kernel name paused script type]. For example:   search_filter={\"name\":\"foo\",\"creator.name\":\"bar\"},. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name paused script type updated_at], where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=+name,-created_at. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # Returns all jobs, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_jobs(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_jobs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project&#x27;s identifier | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description kernel name paused script type]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;foo\&quot;,\&quot;creator.name\&quot;:\&quot;bar\&quot;},. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name paused script type updated_at], where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;+name,-created_at. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListJobsResponse**](ListJobsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_model_builds**
> ListModelBuildsResponse list_model_builds(project_id, model_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List model builds, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model to get builds for.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [comment creator.email creator.name creator.username crn status], where \"status\" can be one of [pending, succeeded, built, build failed, timedout, pushing, queued, unknown] For example:   search_filter={\"comment\":\"foo\",\"status\":\"pending\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [built_at comment created_at creator.email creator.name creator.username crn status updated_at]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=creator.email. (optional)
page_size = 56 # int | page size of the response model build list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # List model builds, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_model_builds(project_id, model_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_model_builds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model to get builds for. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [comment creator.email creator.name creator.username crn status], where \&quot;status\&quot; can be one of [pending, succeeded, built, build failed, timedout, pushing, queued, unknown] For example:   search_filter&#x3D;{\&quot;comment\&quot;:\&quot;foo\&quot;,\&quot;status\&quot;:\&quot;pending\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [built_at comment created_at creator.email creator.name creator.username crn status updated_at]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;creator.email. | [optional] 
 **page_size** | **int**| page size of the response model build list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListModelBuildsResponse**](ListModelBuildsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_model_deployments**
> ListModelDeploymentsResponse list_model_deployments(project_id, model_id, build_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)

List model deployments, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model to get deployments for.
build_id = 'build_id_example' # str | ID of the model build to get deployments for.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. (optional)
page_size = 56 # int | page size of the response model build list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: []. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=. (optional)

try:
    # List model deployments, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_model_deployments(project_id, model_id, build_id, search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_model_deployments: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model to get deployments for. | 
 **build_id** | **str**| ID of the model build to get deployments for. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. | [optional] 
 **page_size** | **int**| page size of the response model build list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: []. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;. | [optional] 

### Return type

[**ListModelDeploymentsResponse**](ListModelDeploymentsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_models**
> ListModelsResponse list_models(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List models, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project to list models under.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [auth_enabled creator.email creator.name creator.username description name]. For example:   search_filter={\"name\":\"foo\",\"auth_enabled\":\"f\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [auth_enabled created_at creator.email creator.name creator.username description name updated_at]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=created_at. (optional)
page_size = 56 # int | page size of the response model build list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # List models, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_models(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_models: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project to list models under. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [auth_enabled creator.email creator.name creator.username description name]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;foo\&quot;,\&quot;auth_enabled\&quot;:\&quot;f\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [auth_enabled created_at creator.email creator.name creator.username description name updated_at]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;created_at. | [optional] 
 **page_size** | **int**| page size of the response model build list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListModelsResponse**](ListModelsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_news_feeds**
> ListNewsFeedsResponse list_news_feeds(category, page_size=page_size, page_token=page_token)

List the newsfeeds, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
category = 'category_example' # str | 
page_size = 56 # int |  (optional)
page_token = 'page_token_example' # str |  (optional)

try:
    # List the newsfeeds, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_news_feeds(category, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_news_feeds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **str**|  | 
 **page_size** | **int**|  | [optional] 
 **page_token** | **str**|  | [optional] 

### Return type

[**ListNewsFeedsResponse**](ListNewsFeedsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_project_collaborators**
> ListProjectCollaboratorsResponse list_project_collaborators(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List project collaborators.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The identifier of the project.
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [username, permission]. For example:   search_filter={\"username\":\"foo\", \"permission\": \"read\"},. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [username, permission]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=-username,+permission. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # List project collaborators.
    api_response = api_instance.list_project_collaborators(project_id, search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_project_collaborators: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The identifier of the project. | 
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [username, permission]. For example:   search_filter&#x3D;{\&quot;username\&quot;:\&quot;foo\&quot;, \&quot;permission\&quot;: \&quot;read\&quot;},. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [username, permission]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;-username,+permission. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListProjectCollaboratorsResponse**](ListProjectCollaboratorsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_project_files**
> ListProjectFilesResponse list_project_files(project_id, path)

List files/subdirectories at a specified path

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The identifier of the project that contains the files to list.
path = 'path_example' # str | Path to list, relative to project root (/home/cdsw)

try:
    # List files/subdirectories at a specified path
    api_response = api_instance.list_project_files(project_id, path)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_project_files: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The identifier of the project that contains the files to list. | 
 **path** | **str**| Path to list, relative to project root (/home/cdsw) | 

### Return type

[**ListProjectFilesResponse**](ListProjectFilesResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_project_names**
> ListProjectNamesResponse list_project_names(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

Return all the project names the user has access to, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [name]. For example:   search_filter={\"name\":\"project name\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [name]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:  sort=name. (optional)
page_size = 56 # int | page size of the response runtime repo list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # Return all the project names the user has access to, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_project_names(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_project_names: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [name]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;project name\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [name]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:  sort&#x3D;name. | [optional] 
 **page_size** | **int**| page size of the response runtime repo list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListProjectNamesResponse**](ListProjectNamesResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_projects**
> ListProjectsResponse list_projects(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token, include_public_projects=include_public_projects, include_all_projects=include_all_projects)

Return all projects, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description name owner.email owner.name owner.username]. For example:   search_filter={\"name\":\"foo\",\"creator.name\":\"bar\"},. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description name owner.email owner.name owner.username updated_at]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=-updated_at,+name. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)
include_public_projects = true # bool | Default is false. If include_public_projects is set to true, then it will return all projects user has access to, including public projects. (optional)
include_all_projects = true # bool | Default is false. If include_all_projects is set to true, then it will return all projects in the workspace if user is a site admin. If user is not a site admin, then it will be equivalent to making use of flag include_public_projects and will return all projects user has access to, including public projects. (optional)

try:
    # Return all projects, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_projects(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token, include_public_projects=include_public_projects, include_all_projects=include_all_projects)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_projects: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [creator.email creator.name creator.username description name owner.email owner.name owner.username]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;foo\&quot;,\&quot;creator.name\&quot;:\&quot;bar\&quot;},. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description name owner.email owner.name owner.username updated_at]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;-updated_at,+name. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 
 **include_public_projects** | **bool**| Default is false. If include_public_projects is set to true, then it will return all projects user has access to, including public projects. | [optional] 
 **include_all_projects** | **bool**| Default is false. If include_all_projects is set to true, then it will return all projects in the workspace if user is a site admin. If user is not a site admin, then it will be equivalent to making use of flag include_public_projects and will return all projects user has access to, including public projects. | [optional] 

### Return type

[**ListProjectsResponse**](ListProjectsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_registered_models**
> ListRegisteredModelsResponse list_registered_models(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List registered models.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search_filter = {\"model_name\": \"model_name\"}  search_filter = {\"creator_id\": \"<sso name or user name>\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name script status updated_at]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=-created_at. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)

try:
    # List registered models.
    api_response = api_instance.list_registered_models(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_registered_models: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search_filter &#x3D; {\&quot;model_name\&quot;: \&quot;model_name\&quot;}  search_filter &#x3D; {\&quot;creator_id\&quot;: \&quot;&lt;sso name or user name&gt;\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [created_at creator.email creator.name creator.username description kernel name script status updated_at]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;-created_at. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 

### Return type

[**ListRegisteredModelsResponse**](ListRegisteredModelsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_runtime_addons**
> ListRuntimeAddonsResponse list_runtime_addons(search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)

List the available runtime addons, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [\"identifier\", \"component\", \"display_name\", \"status\"]. For example:   search_filter = {\"component\": \"Spark\", \"status\": \"AVAILABLE\"},. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. (optional)

try:
    # List the available runtime addons, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_runtime_addons(search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_runtime_addons: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [\&quot;identifier\&quot;, \&quot;component\&quot;, \&quot;display_name\&quot;, \&quot;status\&quot;]. For example:   search_filter &#x3D; {\&quot;component\&quot;: \&quot;Spark\&quot;, \&quot;status\&quot;: \&quot;AVAILABLE\&quot;},. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. | [optional] 

### Return type

[**ListRuntimeAddonsResponse**](ListRuntimeAddonsResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_runtime_repos**
> ListRuntimeReposResponse list_runtime_repos(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

List Runtime repos.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [id name url]. For example:   search_filter={\"id\":\"1\",\"name\":\"My Repo\",\"url\":\"my.url\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [id name url]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=id. (optional)
page_size = 56 # int | page size of the response runtime repo list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # List Runtime repos.
    api_response = api_instance.list_runtime_repos(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_runtime_repos: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [id name url]. For example:   search_filter&#x3D;{\&quot;id\&quot;:\&quot;1\&quot;,\&quot;name\&quot;:\&quot;My Repo\&quot;,\&quot;url\&quot;:\&quot;my.url\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [id name url]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;id. | [optional] 
 **page_size** | **int**| page size of the response runtime repo list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListRuntimeReposResponse**](ListRuntimeReposResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_runtimes**
> ListRuntimesResponse list_runtimes(search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)

List the available runtimes, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [\"image_identifier\", \"editor\", \"kernel\", \"edition\", \"description\", \"full_version\"]. For example:   search_filter = {\"kernel\":\"Python 3.7\",\"editor\":\"JupyterLab\"},. (optional)
page_size = 56 # int | Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. (optional)
page_token = 'page_token_example' # str | Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [image_identifier, editor, kernel, edition, description, full_version]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=-kernel,+editor. (optional)

try:
    # List the available runtimes, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_runtimes(search_filter=search_filter, page_size=page_size, page_token=page_token, sort=sort)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_runtimes: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [\&quot;image_identifier\&quot;, \&quot;editor\&quot;, \&quot;kernel\&quot;, \&quot;edition\&quot;, \&quot;description\&quot;, \&quot;full_version\&quot;]. For example:   search_filter &#x3D; {\&quot;kernel\&quot;:\&quot;Python 3.7\&quot;,\&quot;editor\&quot;:\&quot;JupyterLab\&quot;},. | [optional] 
 **page_size** | **int**| Page size is an optional argument for number of entries to return in one page. If not specified, the server will determine a page size. If specified, must be respecified for further requests when using the provided next page token in the response. | [optional] 
 **page_token** | **str**| Page token is an optional argument for specifying which page of results to get. If not specified, the first page will be returned, including a token for the next page. Will be empty if there is no next page. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [image_identifier, editor, kernel, edition, description, full_version]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;-kernel,+editor. | [optional] 

### Return type

[**ListRuntimesResponse**](ListRuntimesResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_usage**
> ListUsageResponse list_usage(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token, multi_column_search_filter=multi_column_search_filter, time_range_search_filter=time_range_search_filter)

Return the new usage view based on the caller context, optionally filtered, sorted, and paginated.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [name creator group project_name workload_type status]. For example:   search_filter={\"name\":\"My Session\",\"workload_type\":\"session\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [name creator group project_name cpu memory nvidia_gpu workload_type created_at status]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=name. (optional)
page_size = 56 # int | page size of the response runtime repo list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)
multi_column_search_filter = 'multi_column_search_filter_example' # str | Multi column search filter is an optional HTTP parameter to filter multiple columns. Supported Multi column search filter keys are: [project_or_workload_name]. For example:   multi_column_search_filter={\"project_or_workload_name\":\"name\"}. (optional)
time_range_search_filter = 'time_range_search_filter_example' # str | Time range search filter is an optional HTTP parameter to filter based on the time. Supported Time range search filters are: [created_time]. For example:   time_range_search_filter={\"created_time\":{\"min\":\"2023-12-11 21:06:51\",\"max\":\"2023-12-11 21:08:51\"}}. (optional)

try:
    # Return the new usage view based on the caller context, optionally filtered, sorted, and paginated.
    api_response = api_instance.list_usage(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token, multi_column_search_filter=multi_column_search_filter, time_range_search_filter=time_range_search_filter)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_usage: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [name creator group project_name workload_type status]. For example:   search_filter&#x3D;{\&quot;name\&quot;:\&quot;My Session\&quot;,\&quot;workload_type\&quot;:\&quot;session\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [name creator group project_name cpu memory nvidia_gpu workload_type created_at status]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;name. | [optional] 
 **page_size** | **int**| page size of the response runtime repo list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 
 **multi_column_search_filter** | **str**| Multi column search filter is an optional HTTP parameter to filter multiple columns. Supported Multi column search filter keys are: [project_or_workload_name]. For example:   multi_column_search_filter&#x3D;{\&quot;project_or_workload_name\&quot;:\&quot;name\&quot;}. | [optional] 
 **time_range_search_filter** | **str**| Time range search filter is an optional HTTP parameter to filter based on the time. Supported Time range search filters are: [created_time]. For example:   time_range_search_filter&#x3D;{\&quot;created_time\&quot;:{\&quot;min\&quot;:\&quot;2023-12-11 21:06:51\&quot;,\&quot;max\&quot;:\&quot;2023-12-11 21:08:51\&quot;}}. | [optional] 

### Return type

[**ListUsageResponse**](ListUsageResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_users_quota**
> ListUsersQuotaResponse list_users_quota(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)

Return all the user names and quotas based on the context. Admin gets all the users details.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
search_filter = 'search_filter_example' # str | Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [banned deactivated]. For example:   search_filter={\"deactivated\":\"false\",\"banned\":\"false\"}. (optional)
sort = 'sort_example' # str | Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [username]. where \"+\" means sort by ascending order, and \"-\" means sort by descending order. For example:   sort=username. (optional)
page_size = 56 # int | page size of the response runtime repo list. (optional)
page_token = 'page_token_example' # str | page token for specifying which page to return. (optional)

try:
    # Return all the user names and quotas based on the context. Admin gets all the users details.
    api_response = api_instance.list_users_quota(search_filter=search_filter, sort=sort, page_size=page_size, page_token=page_token)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_users_quota: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_filter** | **str**| Search filter is an optional HTTP parameter to filter results by. Supported search filter keys are: [banned deactivated]. For example:   search_filter&#x3D;{\&quot;deactivated\&quot;:\&quot;false\&quot;,\&quot;banned\&quot;:\&quot;false\&quot;}. | [optional] 
 **sort** | **str**| Sort is an optional HTTP parameter to sort results by. Supported sort keys are: [username]. where \&quot;+\&quot; means sort by ascending order, and \&quot;-\&quot; means sort by descending order. For example:   sort&#x3D;username. | [optional] 
 **page_size** | **int**| page size of the response runtime repo list. | [optional] 
 **page_token** | **str**| page token for specifying which page to return. | [optional] 

### Return type

[**ListUsersQuotaResponse**](ListUsersQuotaResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_v2_keys**
> ListV2KeysResponse list_v2_keys(username)

Get all API V2 keys

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
username = 'username_example' # str | username of the user whose V2 keys you want to get

try:
    # Get all API V2 keys
    api_response = api_instance.list_v2_keys(username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_v2_keys: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **str**| username of the user whose V2 keys you want to get | 

### Return type

[**ListV2KeysResponse**](ListV2KeysResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workload_status**
> ListWorkloadStatusResponse list_workload_status()

Return the workload statuses.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()

try:
    # Return the workload statuses.
    api_response = api_instance.list_workload_status()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_workload_status: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ListWorkloadStatusResponse**](ListWorkloadStatusResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workload_types**
> ListWorkloadTypesResponse list_workload_types()

Return the workload types.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()

try:
    # Return the workload types.
    api_response = api_instance.list_workload_types()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->list_workload_types: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ListWorkloadTypesResponse**](ListWorkloadTypesResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **log_experiment_run_batch**
> LogExperimentRunBatchResponse log_experiment_run_batch(body, project_id, experiment_id, run_id)

Bulk update an experiment run details like metrics, params, tags in one request.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.LogExperimentRunBatchRequest() # LogExperimentRunBatchRequest | 
project_id = 'project_id_example' # str | 
experiment_id = 'experiment_id_example' # str | 
run_id = 'run_id_example' # str | ID of the ExperimentRun to log under

try:
    # Bulk update an experiment run details like metrics, params, tags in one request.
    api_response = api_instance.log_experiment_run_batch(body, project_id, experiment_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->log_experiment_run_batch: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LogExperimentRunBatchRequest**](LogExperimentRunBatchRequest.md)|  | 
 **project_id** | **str**|  | 
 **experiment_id** | **str**|  | 
 **run_id** | **str**| ID of the ExperimentRun to log under | 

### Return type

[**LogExperimentRunBatchResponse**](LogExperimentRunBatchResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **register_custom_runtime**
> RegisterCustomRuntimeResponse register_custom_runtime(body)

Register a runtime, given the URL to the image in the docker registry

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.RegisterCustomRuntimeRequest() # RegisterCustomRuntimeRequest | 

try:
    # Register a runtime, given the URL to the image in the docker registry
    api_response = api_instance.register_custom_runtime(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->register_custom_runtime: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RegisterCustomRuntimeRequest**](RegisterCustomRuntimeRequest.md)|  | 

### Return type

[**RegisterCustomRuntimeResponse**](RegisterCustomRuntimeResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **restart_application**
> Application restart_application(project_id, application_id)

Start an application.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The public project identifier
application_id = 'application_id_example' # str | The public application identifier

try:
    # Start an application.
    api_response = api_instance.restart_application(project_id, application_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->restart_application: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The public project identifier | 
 **application_id** | **str**| The public application identifier | 

### Return type

[**Application**](Application.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **restart_model_deployment**
> ModelDeployment restart_model_deployment(project_id, model_id, build_id, deployment_id)

Restart a model deployment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model containing the deployment.
build_id = 'build_id_example' # str | ID of the build containing the deployment.
deployment_id = 'deployment_id_example' # str | ID of the deployment to restart.

try:
    # Restart a model deployment.
    api_response = api_instance.restart_model_deployment(project_id, model_id, build_id, deployment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->restart_model_deployment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model containing the deployment. | 
 **build_id** | **str**| ID of the build containing the deployment. | 
 **deployment_id** | **str**| ID of the deployment to restart. | 

### Return type

[**ModelDeployment**](ModelDeployment.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rotate_v1_key**
> RotateV1KeyResponse rotate_v1_key(body, username)

Rotate API V1 key

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.RotateV1KeyRequest() # RotateV1KeyRequest | 
username = 'username_example' # str | username of the user whose V1 key you want to rotate

try:
    # Rotate API V1 key
    api_response = api_instance.rotate_v1_key(body, username)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->rotate_v1_key: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RotateV1KeyRequest**](RotateV1KeyRequest.md)|  | 
 **username** | **str**| username of the user whose V1 key you want to rotate | 

### Return type

[**RotateV1KeyResponse**](RotateV1KeyResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **stop_application**
> Application stop_application(project_id, application_id)

Stop an application.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The public project identifier
application_id = 'application_id_example' # str | The public application identifier

try:
    # Stop an application.
    api_response = api_instance.stop_application(project_id, application_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->stop_application: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The public project identifier | 
 **application_id** | **str**| The public application identifier | 

### Return type

[**Application**](Application.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## Cursor

The CML API has a family of “list_” functions to get lists of entities (jobs, projects, etc.). These “list_” functions give full control over pagination, which can be useful in some circumstances. But in normal use you will find it easier to wrap list_ calls with a Cursor, which abstracts away pagination and returns the jobs, projects, etc. directly.

```python
import cmlapi
from cmlapi import Cursor
api_url="http://workspacedemo.cloudera.com"
api_key="sfafagagirwyf37434848...."
api_client=cmlapi.default_client(url=api_url,cml_api_key=api_key)
# Iterate over all projects
for project in Cursor(self.list_projects).items():
  print(project)
# Iterate while passing a positional argument foo and a keyword argument bar=42 to list_jobs:
for job in Cursor(list_jobs, foo, bar=42).items():
    do_stuff(job)
```

# **stop_job_run**
> JobRun stop_job_run(project_id, job_id, run_id)

Stops a job run. Encoded as a custom method.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the job
job_id = 'job_id_example' # str | ID of the job containing the job run.
run_id = 'run_id_example' # str | ID of the job run to delete.

try:
    # Stops a job run. Encoded as a custom method.
    api_response = api_instance.stop_job_run(project_id, job_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->stop_job_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the job | 
 **job_id** | **str**| ID of the job containing the job run. | 
 **run_id** | **str**| ID of the job run to delete. | 

### Return type

[**JobRun**](JobRun.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **stop_model_deployment**
> ModelDeployment stop_model_deployment(project_id, model_id, build_id, deployment_id)

Stop a model deployment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model containing the deployment.
build_id = 'build_id_example' # str | ID of the build containing the deployment.
deployment_id = 'deployment_id_example' # str | ID of the deployment to stop.

try:
    # Stop a model deployment.
    api_response = api_instance.stop_model_deployment(project_id, model_id, build_id, deployment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->stop_model_deployment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model containing the deployment. | 
 **build_id** | **str**| ID of the build containing the deployment. | 
 **deployment_id** | **str**| ID of the deployment to stop. | 

### Return type

[**ModelDeployment**](ModelDeployment.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_accelerator_labels_admin_config**
> UpdateNodeLabelAdminConfigResponse update_accelerator_labels_admin_config(body)

Update admin_config_max_per_workload in Node Labels

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.UpdateNodeLabelAdminConfigRequest() # UpdateNodeLabelAdminConfigRequest | 

try:
    # Update admin_config_max_per_workload in Node Labels
    api_response = api_instance.update_accelerator_labels_admin_config(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_accelerator_labels_admin_config: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateNodeLabelAdminConfigRequest**](UpdateNodeLabelAdminConfigRequest.md)|  | 

### Return type

[**UpdateNodeLabelAdminConfigResponse**](UpdateNodeLabelAdminConfigResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_application**
> Application update_application(body, project_id, application_id)

Update an application

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.Application() # Application | The application containing some number of fields to update.
project_id = 'project_id_example' # str | The public project identifier
application_id = 'application_id_example' # str | public identifier of the application.

try:
    # Update an application
    api_response = api_instance.update_application(body, project_id, application_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_application: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Application**](Application.md)| The application containing some number of fields to update. | 
 **project_id** | **str**| The public project identifier | 
 **application_id** | **str**| public identifier of the application. | 

### Return type

[**Application**](Application.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_experiment**
> Experiment update_experiment(body, experiment_project_id, experiment_id)

Update an existing experiment.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.Experiment() # Experiment | 
experiment_project_id = 'experiment_project_id_example' # str | Project ID
experiment_id = 'experiment_id_example' # str | Unique identifier for the experiment.

try:
    # Update an existing experiment.
    api_response = api_instance.update_experiment(body, experiment_project_id, experiment_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_experiment: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Experiment**](Experiment.md)|  | 
 **experiment_project_id** | **str**| Project ID | 
 **experiment_id** | **str**| Unique identifier for the experiment. | 

### Return type

[**Experiment**](Experiment.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_experiment_run**
> ExperimentRun update_experiment_run(body, project_id, experiment_id, run_id)

Update an experiment run.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.ExperimentRun() # ExperimentRun | 
project_id = 'project_id_example' # str | The project where the experiment run lives
experiment_id = 'experiment_id_example' # str | ID of the associated experiment.
run_id = 'run_id_example' # str | Unique identifier for the ExperimentRun.

try:
    # Update an experiment run.
    api_response = api_instance.update_experiment_run(body, project_id, experiment_id, run_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_experiment_run: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ExperimentRun**](ExperimentRun.md)|  | 
 **project_id** | **str**| The project where the experiment run lives | 
 **experiment_id** | **str**| ID of the associated experiment. | 
 **run_id** | **str**| Unique identifier for the ExperimentRun. | 

### Return type

[**ExperimentRun**](ExperimentRun.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_job**
> Job update_job(body, project_id, job_id)

Updates a job.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.Job() # Job | The job containing some number of fields to update.
project_id = 'project_id_example' # str | The project containing the job.
job_id = 'job_id_example' # str | Public identifier of the job. Output only.

try:
    # Updates a job.
    api_response = api_instance.update_job(body, project_id, job_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_job: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Job**](Job.md)| The job containing some number of fields to update. | 
 **project_id** | **str**| The project containing the job. | 
 **job_id** | **str**| Public identifier of the job. Output only. | 

### Return type

[**Job**](Job.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_model**
> Model update_model(body, project_id, model_id)

Update a model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.UpdateSingleModel() # UpdateSingleModel | The model containing some number of fields to update.
project_id = 'project_id_example' # str | ID of the project containing the model.
model_id = 'model_id_example' # str | ID of the model. A model CRN looks like <workspace CRN>/<UUID>. The ID is the UUID portion of the CRN.

try:
    # Update a model.
    api_response = api_instance.update_model(body, project_id, model_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateSingleModel**](UpdateSingleModel.md)| The model containing some number of fields to update. | 
 **project_id** | **str**| ID of the project containing the model. | 
 **model_id** | **str**| ID of the model. A model CRN looks like &lt;workspace CRN&gt;/&lt;UUID&gt;. The ID is the UUID portion of the CRN. | 

### Return type

[**Model**](Model.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_project**
> Project update_project(body, project_id)

Update an existing project.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.Project() # Project | The project object containing some number of fields to update.
project_id = 'project_id_example' # str | An opaque public identifier for the project. Output only.

try:
    # Update an existing project.
    api_response = api_instance.update_project(body, project_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_project: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Project**](Project.md)| The project object containing some number of fields to update. | 
 **project_id** | **str**| An opaque public identifier for the project. Output only. | 

### Return type

[**Project**](Project.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_project_file_metadata**
> FileInfo update_project_file_metadata(body, project_id, path)

Update file metadata, such as renaming.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.FileInfo() # FileInfo | The FileInfo object representing the updated metadata for the file.
project_id = 'project_id_example' # str | The identifier of the project that contains the file or directory.
path = 'path_example' # str | The path to the file to update, relative to /home/cdsw

try:
    # Update file metadata, such as renaming.
    api_response = api_instance.update_project_file_metadata(body, project_id, path)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_project_file_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**FileInfo**](FileInfo.md)| The FileInfo object representing the updated metadata for the file. | 
 **project_id** | **str**| The identifier of the project that contains the file or directory. | 
 **path** | **str**| The path to the file to update, relative to /home/cdsw | 

### Return type

[**FileInfo**](FileInfo.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_registered_model**
> RegisteredModel update_registered_model(body)

Update a Registered model.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.UpdateRegisteredModelRequest() # UpdateRegisteredModelRequest | 

try:
    # Update a Registered model.
    api_response = api_instance.update_registered_model(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_registered_model: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateRegisteredModelRequest**](UpdateRegisteredModelRequest.md)|  | 

### Return type

[**RegisteredModel**](RegisteredModel.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_registered_model_version**
> RegisteredModelVersion update_registered_model_version(body, model_id)

Update a Registered model version.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.UpdateRegisteredModelVersionRequest() # UpdateRegisteredModelVersionRequest | 
model_id = 'model_id_example' # str | Model ID.

try:
    # Update a Registered model version.
    api_response = api_instance.update_registered_model_version(body, model_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_registered_model_version: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateRegisteredModelVersionRequest**](UpdateRegisteredModelVersionRequest.md)|  | 
 **model_id** | **str**| Model ID. | 

### Return type

[**RegisteredModelVersion**](RegisteredModelVersion.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_runtime_addon_status**
> UpdateRuntimeAddonStatusResponse update_runtime_addon_status(body)

Update runtime addons

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.UpdateRuntimeAddonStatusRequest() # UpdateRuntimeAddonStatusRequest | 

try:
    # Update runtime addons
    api_response = api_instance.update_runtime_addon_status(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_runtime_addon_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateRuntimeAddonStatusRequest**](UpdateRuntimeAddonStatusRequest.md)|  | 

### Return type

[**UpdateRuntimeAddonStatusResponse**](UpdateRuntimeAddonStatusResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_runtime_repo**
> RuntimeRepo update_runtime_repo(body, runtimerepo_id)

Update a Runtime repo.

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.RuntimeRepo() # RuntimeRepo | The runtimerepo object containing some number of fields to update.
runtimerepo_id = 56 # int | The numeric identifier for this runtime repo

try:
    # Update a Runtime repo.
    api_response = api_instance.update_runtime_repo(body, runtimerepo_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_runtime_repo: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RuntimeRepo**](RuntimeRepo.md)| The runtimerepo object containing some number of fields to update. | 
 **runtimerepo_id** | **int**| The numeric identifier for this runtime repo | 

### Return type

[**RuntimeRepo**](RuntimeRepo.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_runtime_status**
> UpdateRuntimeStatusResponse update_runtime_status(body)

Update the status of selected runtimes

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
body = cmlapi.UpdateRuntimeStatusRequest() # UpdateRuntimeStatusRequest | 

try:
    # Update the status of selected runtimes
    api_response = api_instance.update_runtime_status(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->update_runtime_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdateRuntimeStatusRequest**](UpdateRuntimeStatusRequest.md)|  | 

### Return type

[**UpdateRuntimeStatusResponse**](UpdateRuntimeStatusResponse.md)


### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upload_file**
> upload_file(project_id, file=file)

upload a file as a multi-part upload

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
project_id = 'project_id_example' # str | The project this model belongs to.
file = 'file_example' # str |  (optional)

try:
    # upload a file as a multi-part upload
    api_instance.upload_file(project_id, file=file)
except ApiException as e:
    print("Exception when calling CMLServiceApi->upload_file: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| The project this model belongs to. | 
 **file** | **str**|  | [optional] 

### Return type

void (empty response body)


### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validate_custom_runtime**
> ValidateCustomRuntimeResponse validate_custom_runtime(url=url)

Validate a runtime, given the URL to the image in the docker registry

### Example
```python
from __future__ import print_function
import time
import cmlapi
from cmlapi.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = cmlapi.CMLServiceApi()
url = 'url_example' # str |  (optional)

try:
    # Validate a runtime, given the URL to the image in the docker registry
    api_response = api_instance.validate_custom_runtime(url=url)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CMLServiceApi->validate_custom_runtime: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **url** | **str**|  | [optional] 

### Return type

[**ValidateCustomRuntimeResponse**](ValidateCustomRuntimeResponse.md)


### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

