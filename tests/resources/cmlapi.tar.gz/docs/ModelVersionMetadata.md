# ModelVersionMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mlops_type** | [**MLOPSType**](MLOPSType.md) |  | [optional] 
**tags** | [**list[Tag]**](Tag.md) | tags for model. | [optional] 
**workspace_url** | **str** | Workspace URL to track back the model origins. | [optional] 
**project_id** | **str** | Project ID. | [optional] 
**owner** | [**ShortUser**](ShortUser.md) |  | [optional] 
**mlflow_metadata** | [**MLflowMetadata**](MLflowMetadata.md) |  | [optional] 
**simple_metadata** | [**SimpleMetadata**](SimpleMetadata.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

