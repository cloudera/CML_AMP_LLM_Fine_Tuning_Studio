# CustomRuntimeImageDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**registry** | **str** |  | [optional] 
**editor** | **str** |  | [optional] 
**kernel** | **str** |  | [optional] 
**edition** | **str** |  | [optional] 
**version** | **str** |  | [optional] 
**maintenance_version** | **int** |  | [optional] 
**description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

