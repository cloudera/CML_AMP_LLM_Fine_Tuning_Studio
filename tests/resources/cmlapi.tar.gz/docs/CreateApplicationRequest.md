# CreateApplicationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **str** |  | [optional] 
**name** | **str** | Name of the new application. | [optional] 
**subdomain** | **str** |  | [optional] 
**description** | **str** | The description of the application. | [optional] 
**script** | **str** | The script to run for the new application. | [optional] 
**cpu** | **float** | CPU cores to allocate to application (default 1). | [optional] 
**memory** | **float** | Memory in GB to allocate to application (default 1). | [optional] 
**nvidia_gpu** | **int** | Number of Nvidia GPUs to allocate to this application (default 0). | [optional] 
**environment** | **dict(str, str)** | Default environment variables to include in application. | [optional] 
**kernel** | **str** | Kernel to run the job runs on. Possible values are python3, python2, r, or scala. Leave blank for runtimes. | [optional] 
**bypass_authentication** | **bool** |  | [optional] 
**runtime_identifier** | **str** | Runtime image identifier to run the application with. | [optional] 
**runtime_addon_identifiers** | **list[str]** | Runtime addons to run the application with if using runtimes. | [optional] 
**run_as** | **int** | UserID of service account used to run the application. | [optional] 
**cdv_app** | **bool** |  | [optional] 
**accelerator_label_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

