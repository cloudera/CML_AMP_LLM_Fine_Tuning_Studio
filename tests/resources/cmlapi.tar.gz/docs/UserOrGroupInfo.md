# UserOrGroupInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**html_url** | **str** |  | [optional] 
**url** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**user_name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

