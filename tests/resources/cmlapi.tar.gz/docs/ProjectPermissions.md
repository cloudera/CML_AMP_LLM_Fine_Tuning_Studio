# ProjectPermissions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**read** | **bool** | Read-only, aka Viewer. Can view code, data, and results. | [optional] 
**write** | **bool** | Read-write, aka Contributor. Can view and modify all project resources. | [optional] 
**admin** | **bool** | Administrator. Can view and modify all project resources, add new collaborators, and delete the project. | [optional] 
**business_user** | **bool** | business_user can access application. | [optional] 
**operator** | **bool** | operator can start or stop pre-existing jobs. | [optional] 
**inherit** | **bool** | inherit is meant to be used only for teams. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

