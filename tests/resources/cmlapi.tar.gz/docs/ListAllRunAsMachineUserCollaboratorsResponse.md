# ListAllRunAsMachineUserCollaboratorsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**run_as_machine_user_collaborators** | [**list[RunAsMachineUserCollaborator]**](RunAsMachineUserCollaborator.md) |  | [optional] 
**next_page_token** | **str** | Next page token is a value that can be added to a new ListProjectCollaborators call to fetch the next page of projects, if any remain. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

