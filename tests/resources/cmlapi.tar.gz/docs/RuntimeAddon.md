# RuntimeAddon

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **str** | The unique identifier of the runtime addon. | [optional] 
**component** | **str** | The component this addon relates to, i.e. Spark. | [optional] 
**display_name** | **str** | The display name of the addon. | [optional] 
**status** | **str** | The addon&#x27;s status. | [optional] 
**manageable** | **bool** | Manageable addon. | [optional] 
**created_at** | **datetime** | When the deployment was created. | [optional] 
**id** | **int** | ID of the addon. | [optional] 
**reason** | **str** | Reason of not availability. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

